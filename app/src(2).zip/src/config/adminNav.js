/**
 * Created by zyy on 2017/2/19.
 */
module.exports= [
  {type:'change',content:'管理banner'},
  {type:'change',content:'修改一级目录'},
  {type:'change',content:'修改二级目录'},
  {type:'change',content:'修改试题名称'},

  {type:'creat',content:'添加一级目录'},
  {type:'creat',content:'添加二级目录'},
  {type:'creat',content:'添加试题名称'}

];
