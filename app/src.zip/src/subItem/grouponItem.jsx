"use strict";
const React = require("react");
const moment = require("moment");
const util = require('pin-util/src/web_util');
const GrouponStatus = require("pin-data/enum/grouponStatus");
const statusText = {
    1 : ['组团进行中', 'status t-warning'],
    2 : ['组团成功', 'status t-suc'],
    3 : ['组团失败', 'status t-err'],
    4 : ['团取消','status t-err']
};
class GrouponItem extends React.Component{

    render(){
        let {groupon,showOrder,showGroupon,goodsDetail} = this.props,text,statusClass;

        let {goods} = groupon,
            groupImage,
            orders = groupon.orders,
            totalPrice = 0,
            totalCount = 0,
            saveMoney;

        if(goods){
            groupImage = util.getImage(goods.image250, goods.imageToken, 'intro');
        }
        orders.forEach((order)=>{
            totalPrice += order.price;
            totalCount += (order.count||1);
        });

        if((groupon.yanPrice|| goods.yanPrice)* totalCount >88){
             saveMoney = (groupon.yanPrice|| goods.yanPrice)*totalCount-totalPrice;
        }else{
             saveMoney = (groupon.yanPrice|| goods.yanPrice)*totalCount +(groupon.yanShipPrice||goods.yanShipPrice) -totalPrice;
        }

        return <div className="list-main">
                    <div className="order-content">
                        <div className="order-img">
                            <img className="comment-picture"
                                 src={groupImage}
                                 alt={goods.name}
                                 width="100%" onClick={()=>{goodsDetail(goods)}}/>
                        </div>
                        <div className="order-p">
                            <div className="good-name" onClick={()=>{goodsDetail(goods)}}>{goods.name}</div>
                            <div className="gray">{groupon.groupQuota || groupon.goods.groupQuota}人团，拼团价 ：
                                <span className="red">¥{goods.mobilePrice}</span>
                            </div>
                            <div className="gray">免运费，组团购买省了 ¥{Math.round(saveMoney*100)/100}</div>
                            <div className="red">该团我参加了 {orders.length} 次，总共支付 ¥{totalPrice}</div>
                        </div>
                    </div>
                    <div className="list-detail">
                        <span className={statusText[groupon.status][1]}>{statusText[groupon.status][0]}</span>
                        <span className="btns">
                            <button className="aside"
                                    onClick={()=>{showOrder(orders[0])}}>订单详情
                            </button>
                             <button  onClick={()=>{showGroupon(groupon);}}>参团详情</button>
                        </span>
                    </div>
                </div>;
    }
}

module.exports =  GrouponItem;