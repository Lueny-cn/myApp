"use strict"
const React = require("react");

class PacketTtem extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            confirmDialogVisible: true,
            confirmText: "恭喜你获得了1元红包",
            confirm: null
        };
    }


    render() {

        // className:1.red ,2.yellow,3.gary fail,4.gary uesd;
        //className:list:红包列表

        let {num,time,intro,type,typeIntro} = this.props;

        return <div className="w-packet red list">
            <div className="packetName">{type}</div>
            <div className="numDiv"><span className="num">{num}</span>元</div>
            <div className="intro">
                <p>直减{num}元</p>
                <p className="introduct">{intro}</p>
            </div>
            <div className="useTime">
                有效期 {time}
            </div>
        </div>;
    }
}
module.exports = PacketTtem;