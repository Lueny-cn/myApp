/**
 * 评论
 */
const React = require("react");
const {Link} = require("react-router");
const moment = require("moment");
const Gallery = require("../module/gallery");
const util = require('pin-util/src/web_util');

class CommentItem extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            zoomIn: false,
            active: 0
        }
    }

    render(){
        let {comment} = this.props;
        if(!comment){ return null; }

        return  <div className="w-comment">
                    <div className="w-comment-user">
                        <img className="w-face small" src={comment.frontUserAvatar||util.getCacheUrl('/img/face.png')} alt="头像"/>
                        <div className="w-comment-name"><a href="javascript:void(0);">{comment.frontUserName}</a></div>
                        <div className="w-comment-time">{moment(comment.createTime).format('YYYY-MM-DD HH:mm')}</div>
                    </div>
                    <div className="w-comment-content">{comment.content}</div>
                    {comment.picList.length > 0 &&
                    <div className="w-comment-show">
                        {
                            comment.picList.map((item, n)=>{
                                return <img key={n}
                                            src={item} alt=""
                                            className="comment-picture"
                                            onClick={()=>{this.setState({zoomIn:true,active:n})}}/>
                            })
                        }
                        {this.state.zoomIn &&
                        <Gallery items={comment.picList} onClick={()=>this.setState({zoomIn:false})} active={this.state.active}/>
                        }
                    </div>
                    }
                    <div className="w-comment-type">颜色分类：{comment.skuInfo.join(' ')}</div>

                    {comment.commentReplyVO &&
                    <div className="w-comment-reply">
                        <span className="name">小选回复：</span>
                        {comment.commentReplyVO.replyContent}
                    </div>
                    }
                </div>
    }
}

module.exports = CommentItem;