/**
 * 地址选择
 */
const React = require("react");
const {Link} = require("react-router");

class AddressItem extends React.Component {
    constructor(props){
        super(props);
    }

    render(){
        let {address, editable, selectable, onClick, onIconClick} = this.props;
        let allAddr = address.province.name + address.city.name + address.district.name + address.address;

        return  <div className="w-address" onClick={onClick}>
                    <div className="w-address-main">
                        <div className="w-address-msg">
                            <div className="w-address-name">{address.name}</div>
                            {address.dft && <span className="defultAddr">默认</span>}
                            <div className="w-address-tel">{address.mobile}</div>
                        </div>
                        <div className="w-address-ad">{allAddr}</div>
                    </div>
                    <div className="w-address-icon" onClick={(e)=>{e.stopPropagation();onIconClick&&onIconClick()}}>
                        {selectable && <i className="i-right"></i>}
                        {editable && <i className="i-edit"></i>}
                    </div>
                </div>
    }
}

module.exports = AddressItem;