"use strict";
const React = require("react");
const moment = require("moment");
const util = require('pin-util/src/web_util');
const OrderStatus = require("pin-data/enum/orderStatus");
const connectToStores = require("alt-utils/lib/connectToStores");
const MyOrderAction = require("pin-alt/src/actions/myOrderAction");
const MyOrderStore = require("pin-alt/src/stores/myOrderStore");

const Confirm = require("../module/confirm");


const StatusText = {
    "notPayed": "待支付,未参团",
    "payed": "已支付，组团进行中...",
    "success": "组团成功，等待发货",
    "fail": "组团失败",
    "delete": "订单已取消",
    "invalid": "订单付款超时",
    "payedfail": "支付失败",
    "delivered": "配送中",
    "received": "已签收",
    "cancel": "已取消",
    "kfCancel":"客服已取消订单",
    "refunded":"已退款"
};
class OrderItem extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            confirmDialogVisible : false
        }
    }
    goodsDetail(order){
        let history = this.props.history;
        history.pushState(null, '/goodsDetail/' + order.goods._id);
    }

    // showOrder(order){
    //     let history = this.props.history;
    //     history.pushState(null, '/orderDetail/' + order._id + '?showType =' + this.state.currentType);
    // }

    showDelivery(order){
        let history = this.props.history;
        history.pushState(null, '/delivery/' + order._id);
    }

    render(){

        let {order,confirmReceive,cancelOrder,goPay,showOrder} = this.props,text,statusClass;
        if(!order){
            return null;
        }
        let grouponId = order.grouponId;
        let goods = order.goods;
        let class_name = '';
        switch (order.status) {
            case OrderStatus.DELETED:
                text = StatusText["delete"];
                class_name = 'list-red';
                statusClass = "t-err";
                break;
            case OrderStatus.PAY_FAILED:
                text = StatusText["payedfail"];
                class_name = 'list-red';
                statusClass = "t-err";
                break;
            case OrderStatus.FAILED:
                text = StatusText["fail"];
                class_name = 'list-red';
                statusClass = "t-err";
                break;
            case OrderStatus.NOT_PAYED:
                text = (grouponId ? StatusText["notPayed"] : "待支付");
                class_name = 'list-red';
                statusClass = "t-warning";
                break;
            case OrderStatus.PAYED:
                text = (grouponId ? StatusText["payed"]: "已支付");
                class_name = 'list-green';
                statusClass = "t-warning";
                break;
            case OrderStatus.SUCCESS:
                text = (grouponId ? StatusText["success"]: "正在发货");
                class_name = 'list-green';
                statusClass = "t-suc";
                break;
            case OrderStatus.DELIVERED:
                text = StatusText["delivered"];
                class_name = 'list-green';
                statusClass = "t-suc";
                break;
            case OrderStatus.INVALID:
                text = StatusText["invalid"];
                class_name = 'list-red';
                statusClass = "t-err";
                break;
            case OrderStatus.RECEIVED:
                text = StatusText["received"];
                class_name = 'list-green';
                statusClass = "t-suc";
                break;
            case OrderStatus.FAILED:
                text = StatusText["fail"];
                class_name = 'list-red';
                statusClass = "t-err";
                break;
            case OrderStatus.CANCEL:
                text = StatusText["cancel"];
                class_name = 'list-red';
                statusClass = "t-err";
                break;
            case OrderStatus.KF_CANCEL:
                text = StatusText["kfCancel"];
                class_name = 'list-red';
                statusClass = "t-err";
                break;
            case OrderStatus.REFUNDED:
                text = StatusText["refunded"];
                class_name = 'list-red';
                statusClass = "t-err";
                break;
        }
        return <div className="list-main">
                    <div className="order-num">
                        <span>订单号：{order.yx_order_id}</span>
                        <span className="time gray">{moment(order.create_time).format('YYYY-MM-DD HH:mm:ss')}</span>
                    </div>
                    <div className="order-content" >
                        <div className="order-img">
                            <img className="comment-picture" src={util.getImage(goods.image250,goods.imageToken,'intro')} alt={goods.name} width="100%" onClick={()=>{this.goodsDetail(order)}}/>
                        </div>
                        <div className="order-p">
                            <div className="good-name" onClick={()=>{this.goodsDetail(order)}}>{goods.name}</div>
                            <div className="gray">数量: {order.count || 1}</div>
                            <div className="gray"><span className="red"> ¥ {order.price} </span>
                                {grouponId || order.shipPrice == 0 || order.price >= 88? '免运费' : <span> + {order.shipPrice} 运费</span>}
                            </div>
                        </div>
                    </div>

                    <div className="list-detail">
                        <span className = {class_name}>{text}</span>
                        <span className="btns">
                            {order.status == OrderStatus.NOT_PAYED ?
                                <button className=""
                                        onClick={()=>{goPay(order);}}>
                                    去支付</button> : ""}

                            {[OrderStatus.NOT_PAYED, OrderStatus.PAYED].indexOf(order.status) > -1 ?
                                <button className="aside"
                                        onClick={()=>{cancelOrder(order);}}>
                                    取消订单</button> : ""}

                            {[OrderStatus.DELIVERED].indexOf(order.status) > -1 ?
                                <button className="aside"
                                        onClick={()=>{this.showDelivery(order);}}>
                                    查看物流</button> : ""}

                            {OrderStatus.DELIVERED == order.status?
                                <button className=""
                                        onClick={()=>{confirmReceive(order);}}>
                                    确认收货</button> : ""}

                            {/*{order.status !== OrderStatus.NOT_PAYED ?*/}
                                <button className="aside" onClick={()=>{showOrder(order)}}>订单详情</button>
                                {/*: ""}*/}
                        </span>
                    </div>
                </div>;

    }
}


module.exports =  OrderItem;