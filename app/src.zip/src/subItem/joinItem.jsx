/**
 * Created by Zyingying on 2016/10/27 0027.
 */
const React = require("react");
const {Link} = require("react-router");
const moment = require("moment");

class JoinItem extends React.Component{
    constructor(props) {
        super(props);
        this.state = {
            remainTime: this.getRemainTime()
        }
    }

    zeroFill(n){
        return (n<10 ? '0':'') + n;
    }

    componentWillMount(){
        this.timer = setInterval(()=>{
            this.setState({
                remainTime: this.getRemainTime()
            })
        }, 1000);
    }

    componentWillUnmount(){
        clearInterval(this.timer);
    }

    getRemainTime(){
        let createTime = moment(this.props.group.create_time);
        let finishTime = moment(createTime + 24*60*60*1000);
        let time = moment.duration(finishTime - new Date().getTime());
        let z = this.zeroFill;

        return [z(time.hours()), z(time.minutes()), z(time.seconds())].join(':');
    }

    render(){
        let {group,goods} = this.props;
        let captain = group.captain;
        let remainTime = this.state.remainTime;

        return <div className="w-joinOther">
                    <div className="other-img">
                        <img src={captain.avatar?captain.avatar:"/api/user/getAvatar?uid="+captain.uid+"&size=55"} alt="团长"/>
                    </div>
                    <div className="main-msg">
                        <div className="msg">
                            <div className="otherName">{captain.name || captain.uid}</div>
                            <span className="needNum">还差{goods.groupQuota - group.orders.filter(order => order.status == 1).length}人成团</span>
                        </div>
                        <div className="msg">
                            <span className="place">{captain.location}</span>
                            <span className="remainTime">剩余{remainTime}结束</span>
                        </div>

                    </div>
                    <Link className="w-btn main " to={"/grouponDetail/" + group._id}>
                        去参团 <i className="i-white-right toGoods"></i>
                    </Link>
                </div>;

    }
}

module.exports = JoinItem;