"use strict";

require("./css/style.scss");
require('babel-polyfill');

const React = require("react");
const WeixinUtil = require("./weixinUtil");
const MobileUtil = require("./mobileUtil");
const Msgbox = require("./module/msgbox");
const PacketItem = require("./subItem/packetItem");

class App extends React.Component{
    constructor(props){
        super(props);

        this.state = {
            loading: false,
            hasPacket:false
        };

        this.listenAjax();
        this.setCookie();
    }

    setCookie(){
        let query = this.props.location.query;
        let domain = location.host.replace(/^m\./, '.'); //'.pin.mail.163.com';

        let source = query.utm_source || search('utm_source');
        let medium = query.utm_medium || search('utm_medium');

        let cookie = {};

        cookie.utm_source = source || 'H5';

        if(medium){
            cookie.utm_medium = medium;
        }else{
            cookie.utm_medium = WeixinUtil.isWeixin() ? 'weixin' : 'wap';
        }

        MobileUtil.setCookie('pin_utm', JSON.stringify(cookie), domain);

        function search(key){
            let r = new RegExp('(?:\\?|&)' + key + '=(.+?)(?=$|&)');
            return (location.search.match(r)||[])[1];
        }
    }

    listenAjax(){
        $(document).on('ajaxBeforeSend', ()=>{
            setTimeout(()=>this.setState({loading: true}),0);
        });

        $(document).on('ajaxComplete', ()=>{
            setTimeout(()=>this.setState({loading: false}),0);
        });
    }

    render(){
        let redPacket = (<div className="packetList">
            <PacketItem num={100}
                        time = "2016.06.24-2016.12.15"
                        intro = "全场通用，开团参与均可可以可以"
                        type = "新手红包"
            />
            <PacketItem/>
        </div>)
        return <div>
                    {this.props.children}
                    {this.state.loading && <div className="w-loading"></div>}
                    {this.state.hasPacket &&
                    <Msgbox children={redPacket}
                            title="恭喜你获得了num个红包"
                            center="true"
                            okText="查看红包"
                            cancelText="关闭"
                            onOkClick={()=> {
                                this.setState({
                                    hasPacket: false,
                                })
                                this.props.history.pushState(null, '/redPacket');
                            }}
                            onCancelClick={()=> {
                                this.setState({
                                    hasPacket: false,
                                });

                            }}/>}
                </div>;
    }
}
module.exports = App;