"use strict";
const Flux = require("pin-alt/src/flux");
const GoodsAction = require("pin-alt/src/actions/goodsAction");
class GoodsStore{
    constructor(){
        this.bindActions(GoodsAction);
        this.on('unlisten', () => {
            this.recommends = [];
            this.comments = [];
            this.pagination = null;
            this.err = null;
            this.loading = null;
            this.skuInfos = [];
            this.allLook = [];
            this.goodsDetail = null;
        });
    }

    onGetRecommendsSuccess(results){
        this.loading = false;
        this.recommends = results;
    }

    onGetRecommendsFail(err){
        this.err = err;
    }

    onGetCommentsSuccess(results){
        this.loading = false;
        this.comments = results.commentPagination.page == 1 ? this.comments = results.result : this.comments.concat(results.result);
        this.pagination = results.commentPagination;
    }

    onGetCommendsFail(err){
        this.err = err;
    }

    onGetSkuChooseSuccess(results){
        this.skuInfos = results;
    }

    onGetSkuChooseFail(err){
        this.err = err;
    }

    onGetAllLookSuccess(results){
        this.allLook = results;
    }

    onGetAllLookFail(err){
        this.err = err;
    }
    onGetDetailSuccess(results){
        this.goodsDetail = results;
    }

    onGetDetailFail(err){
        this.err = err;
    }
}
module.exports = Flux.createStore(GoodsStore);