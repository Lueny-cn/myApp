"use strict";
const Flux = require("pin-alt/src/flux");
const PerMsgAction = require("../action/perMsgAction");
const moment = require("moment");

class PersonalMsgStore{
    constructor(){
        this.bindActions(PerMsgAction);
        this.gender = 0;
    }
    onGetUserSuccess(results){
        results.birthday = moment(results.birthday).format('YYYY-MM-DD');
        this.userMsg = results;

    }

    onGetUserFail(){}

    onGetMsgSuccess(){}


}
module.exports = Flux.createStore(PersonalMsgStore);
