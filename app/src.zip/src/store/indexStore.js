"use strict";
const Flux = require("pin-alt/src/flux");
const IndexAction = require("../action/indexAction");
class IndexStore{
  constructor(){
    this.bindActions(IndexAction);
    this.banners = [];
    this.categories = [];
    this.currentCateId = null;
    this.cateGoodsMap = {};
    this.fetchedCate = {};
    this.cateGoods = [];
    this.goods = [];
    this.err = null;
    this.loading = null;
    this.scrollPosition = 0;
  }
  onSetScrollPositionSuccess(position){
    this.scrollPosition = position;
  }

  onFetchGoodsByCategoryIdSuccess(results){
      this.loading = false;

      let cateGoodsResult = results[0],isGet = results[1],isRefresh = results[2];
      let goods = cateGoodsResult.goods;
      this.fetchedCate[cateGoodsResult.categoryId] = true;
      this.cateGoodsMap[cateGoodsResult.categoryId] = goods;

      if(isGet){
          this.currentCateId = cateGoodsResult.categoryId;

          if(isRefresh){
              this.cateGoods = goods;
          } else {
              this.cateGoods = this.cateGoods.concat(goods);
          }
      }
  }

  onGetGoodsByCategoryIdSuccess(results){
    let cateId = results[0],isRefresh = results[1];
    let cateGoods = this.cateGoodsMap[cateId];

    this.currentCateId = cateId;
    if(isRefresh){
      this.scrollPosition = 0;
      this.cateGoods = cateGoods;
    }else{
      this.cateGoods = this.cateGoods.concat(cateGoods);
    }
  }
  onGetGoodsByCategoryIdFromCacheSuccess(results){
    let cateId = results[0],isRefresh = results[1];
    let cateGoods = this.cateGoodsMap[cateId];

    this.currentCateId = cateId;

    if(isRefresh){
      this.scrollPosition = 0;
      this.cateGoods = cateGoods;
    }else{
      this.cateGoods = this.cateGoods.concat(cateGoods);
    }
  }
  onGetCategoriesSuccess(results){
    this.loading = false;
    this.categories = results.sort((a, b) => {
      if('position' in a && 'position' in b){
        return a.position - b.position;
      }else if('position' in a){
        return 1;
      }else if('position' in b){
        return -1;
      }else{
        return 0;
      }
    });
  }
  onGetGoodsSuccess(results){
    this.loading = false;
    this.goods = results;
  }
  onGetBannersSuccess(results){
    this.loading = false;
    this.banners = results;
  }

  onGetGoodsByCategoryIdFail(err){
    this.err = err;
  }
  onGetCategoriesFail(err){
    this.err = err;
  }
  onGetGoodsFail(err){
    this.err = err;
  }
  onGetBannersFail(err){
    this.err = err;
  }
}
module.exports = Flux.createStore(IndexStore);

