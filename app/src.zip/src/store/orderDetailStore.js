"use strict";
const Flux = require("pin-alt/src/flux");
const MyOrderAction = require("pin-alt/src/actions/myOrderAction");
const OrderStatus = require("pin-data/enum/orderStatus");
const util = require('pin-alt/src/util');
class OrderDetailStore{

    constructor(){
        this.bindActions(MyOrderAction);
        this.deliveryInfo =  null;
        this.order = null;
        this.loading = true;
    }


    onGetOrderInfoSuccess(result){
        this.order = result.order;
        this.grouponId = result.grouponId;
        this.groupQuota = result.groupQuota;
        this.loading = false;
    }

    onGetDeliveryInfoSuccess(result){
        this.deliveryInfo = result;
        this.loading = false;
    }

    onCloseDeliveryInfo(){
        this.deliveryInfo = null;
        this.loading = false;
    }

    onCancelOrderSuccess(orderId){
        if(this.order && this.order._id == orderId){
            this.order.status = OrderStatus.CANCEL;
        }
    }

    onCancelOrderFail(result){
        util.showPopup('暂时无法取消订单,请稍候再试');
    }

    onConfirmOrderSuccess(orderId){
        if(this.order && this.order._id == orderId){
            this.order.status = OrderStatus.RECEIVED;
        }
    }

    onConfirmOrderFail(result){
        util.showPopup('暂时无法确认收货,请稍候再试');
    }

    //TODO:
    onGetOrdersFail(result){
        this.err = result;
        util.showPopup('暂时无法查询到订单信息,请稍候再试');
    }

    onGetDeliveryInfoFail(result){
        util.showPopup('暂时无法查询到物流信息,请稍候再试');
    }

    onGetOrderInfoFail(err){
        this.err = err;
        util.showPopup('暂时无法查询到订单信息,请稍候再试');
    }

}

module.exports = Flux.createStore(OrderDetailStore);
