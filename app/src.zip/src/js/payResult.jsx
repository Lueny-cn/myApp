"use strict"
const {Link} = require("react-router");
const React = require("react");

const connectToStores = require("alt-utils/lib/connectToStores");
const OrderStore = require("pin-alt/src/stores/myOrderStore");

class PayResult extends React.Component{
    constructor(props) {
        super(props);
    }

    static getStores(){
        return [OrderStore];
    }

    static getPropsFromStores(){
		return {
			...OrderStore.getState(),
		}
    }

    render(){
        let {orderId} = this.props.location.query;
        return <div className="f-page result">
            <div className="f-body fixedFooter">
                <p className="icon"><i className="i-suc"></i></p>
                <h1>支付成功！请等待收货</h1>
                {orderId && <p className="orderId">订单编号：{orderId}</p>}
            </div>
            <div className="f-footer shadowed fixed">
                <div className="w-operation divided">
                    <Link to="/" className="back"><i className="i-home active"></i>首页</Link>
                    <Link
                        to={'/myOrders'}
                        className="main">
                        查看我的订单
                    </Link>
                </div>
            </div>
        </div>;
    }
}
module.exports = connectToStores(PayResult);