"use strict"
const React = require("react");
const WeixinUtil = require('../weixinUtil');
const MobileUtil = require('../mobileUtil');
const URS = window.URS;

class Login extends React.Component{

    componentDidMount(){
        let {location, history} = this.props;
        let nextState = location.state && location.state.nextState;
        let url = encodeURIComponent(window.location.href.replace('/login', '/redirect').replace(/\?[^?]+$/, ''));

        if(WeixinUtil.isWeixin()){
            try{
                // localStorage.setItem(MobileUtil.WX_LOGIN_TIME, new Date().getTime());
                MobileUtil.setCookie(MobileUtil.WX_LOGINED, 1);
                localStorage.setItem(MobileUtil.REDIRECT, JSON.stringify(nextState));
            }catch(e){}
            setTimeout(()=>{
                window.location.href = 'http://reg.163.com/outerLogin/oauth2/connect.do?target=6&product=pin&url=' + url + '&url2=' + url;
            }, 0);
        }else{
            let urs = new URS({
                product: 'pin',
                promark: 'vVPfaIw',
                host: 'pin.mail.163.com',
                page: 'login',
                skin: 1,
                needUnLogin: 1,
                defaultUnLogin: 0,
                includeBox: 'login',
                style: `
                    .g-bd{width: 320px;margin:auto;}
                    .m-header .headimg{width:184px;height:32px;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOgAAAAoCAYAAAD0QbbMAAAJTElEQVR42u3deWwUVRwH8Le7UJBDrBSDBLAWUAIWiqigokIsl6BgpBwSvDHggfUERVNQElBQuRPAK4BgBVRAJLpZPIgXknqiRC1oRTmUWls5C1u/MdNk8vP35s3MTmef0/nj80d35rf7Zna/nZ03782KNV27mrWEMTAdFsKSNJgL04x2tAbhQAu4F1ZDPE02wFIYD6eBqMceJvtmksZtneGyrcthLRRBNxAO9Yc4Mb12ee1KUXgM/oYajRyHZUbwhEJb2K1Z+w9Ar3oc0JfJ/liscVvfdNnWR0ndWvJ5VXkfaohhNKBLoEZjn0NTxYa+omnby6BhGNDABjQTqkjtFojZqO0NNcQPEDUHdJCxQHfTQEjEyE7SzaUBDN8cKFc4RvbDUYt1e4OAsVDq0k5YCef5FVDDfOY9f8BGXTFTNwGEOaAbjQWcCij3lbwt+yACgpHFrL8bboMCH90AcaYtQwIY0MVQ46E+IGCiB891FC73MaAd4SSp/xMyLWraQzWp+R1OoQHdz2zgImgFIg1OhSJIMu1qI9tYZt3r09T+TmFAfQ4o7zMQjM6Qz/iE1G8gy/uCsPAG04ZCi/VnM+s/QdcTTBC+AqGBdcwG5MoCqlEo2ocBTVtAqQwP211h1Ocaf/tCMA8uA6GBh1IM6BqYlQaLgxxQeiRSSHBHJY7pklQHKHBoHGxm9nuLIAWUfvc+B84EYaErlBK1h+m+IBSKmPo8/j+pOqAaGxL24tZ5L26P+hbQdhCHKAiJ0Ra9UFNhHAgLm0jtCWgaBjQMqAu59S2gEaNRUxSjL2j9hcayEVAJnSzq95Lab0GEAQ0DWocBzYIcxhZSu5Iszzbqm0E+sYvUfk2WSzGDgxLm5dKAGt6B4xajYeKkthoaG8uyjce2S07W2zKvvcLDgM6EgjSYGAZUn4D6dJnlK1K71UFtBal92bxcFdDpxmO7mI1tyKR/G1nnZ+PxOSCIMcxr32UOaNiLq7WlEFeg35B+sVh3dBhQ5wHtY3p8FXniy5naJ8k6y4zHkzCYLHuBqe/iMqBtpWH336VBDij9UHpoSh10ErUJekBjZCDDLYrzz4Hkxa82jwQis1N+IbW/gXAZ0MbMuoeNnf48LPHJK3CQ2y9hQF0HNBvGQCFMtvAh85ztPQxod+ipVUANC0zL/obOIOBzZnhVE1KbQT6wcYhAHvO6K90HFIyZLJrqGAbUcUBbw3pIuny+k9DEg4BmwSKohk46BvQCsrwEzmPqNpE6GvBakyVH34IUAzpZ03BuACHxIJTqzminIAphlsIO+tmRrUuum7cy9V+49UGKY3GXQxFUkRF2egSU2EZP9pm6m0EwupD/gsdgH6k9BE1TDGgMlpLXSrfNio6KmbRGUzN97sVdn2J7K6C764DybtI5oKNVE6sVI/ffUtSvBeEyoFRnGAcrmPo43O6DAtOpgAgD6iigZ0vaUAklsN1CAmZDNggPA/oRxHQOaAy+t9iANSAotjeYN9SDgFJx2YBsv4QBdRXQkczrL6y9vl5HMuAji7tidCDr5hA7mZk0OTZVktr15uXSgDJGGcs5V4JQeF1S+zNEPQ7oBcxX3W9AhAH1NKB96HvpQUDp+34QGtTh1MZJUCbZ7r/IIB2thvpREfhUcouGiM2vLkeY+iIQHgc0Qer8dhC+gHnk2m4A+BxQ76c/XgazIEE+j9Qe8nnTMqDUfcz61Q5u6fEZU18CjdwHlD/Sa6Qa7gsDqpxuli0PqP/zWPkc6H8E/cbia2pLEBbOt2jIIo8C2ppcd9VFEq4LA2ppShjQ1AI6UPFkGyFi9wZJXl4Hpd3zmtoN0TCgWgZ0P+xV5ED7TqL3bezk+yW1HaDaxrWrnBQCeiuz/ieQzxgvuV66GvIl+sO3TM2fcI1pvQEwTXJ+kxcGVIuAnoDdsAKGQ6P/3Vhcoi9ZpxymM7XHJFPTXmSOtu9KbvSU4SKgveAoWXcVNJdcMtoiOcKdCkJiEq0xjJKsfzOz7nX1NqDq224WSt73HXXQc9sgGIPlDSRMSRhhcT/Q9YqjZxm0MvzI1F/lMKBtYI9pgPw6uASExFTmeU8obtN4IRxj6p6zqGnG3mkw7MV12ot7HCZAPvSDng41DuxsFsMAixtIx5gNe9PiTaogIcuFcjo1y0FAY/AkzIbR0NzGVLATimlyVKZkIP53qrvdhwF1FdDbSE0qvoMGPgSUdp6+5VdAo1BiWjaP6QhqAu9JAtrDdK5XJTlK9YJKJwF1KRN+klzmyZDURCQdT0chD0QY0P+cj0dSDGh3DwM6yqf5oL/Soat+BfRG09SdqYpfFfuYBtR0rvcrXGRR3w8O1WFAI5KRTFVwruq6L2MiiDCgXS9jtrG/MqBqyz0I5xcQ8SGgpzMdjk/5EdBmRrB2whUgFJpDwhTQ4aZ5nmfYqL8EyusooEVGPTXWouZiyXlnMYgwoP8aJvmhq4wUA9oQHoavoZz0iMscgnKToT799MNgpi23+BHQkTCBjPJRaQTjIQYzXQxO7wYXeRzQayHpsIOnpWQ+4g9sTy8vWg8CeockLMsgUk9+3Wwus/3ZPgQ07WZ4ENBetV+diS8tZttHYKPkP3QPEDZl14OAzlXMcEr8jwJa4qKtUShjvkGIoAc0F/5g2tbJ4S9OHZBMH2rn8CcnkjAShAPzZZeQAmQLGVyu+iq6Bnr6rCUIhUGQdDHFbiizjSOCFNCm8Bq8Da8aEpJzvyoHX7fbwY+ScHZT9EpWM3UzJEfau2Ay8TR8LAl5mwCFMwoVpm0bQjrVdHBY8vMl98MsQzGcdHkeuZUZiSaCdgS9yebOfgmEDWfBLqb+bUVAsmAPE6qpIJSjhdQSIAIkj5kyGIEFGgV0NgjGCBsdTlmqoy4zOKFJUAJKvarYYQegLQiFHGZQwXYYruhyjzC/jrXXqBMKq0gd50gAx+E+CEkolNxQ7HCaw1kJrVy+b/fYuGxXQqbRNQMR1IBmWsxqL4M8mx1C+02BfoG90wPvETKzocjBDm9BjtjUH6QdQfEs9FVM0J8LpWkK6Awb1y/3MqdRd4NQGGu6DW0hmaXkeUBLicdBpEE/OAL7YAdshkk2g3IuPAO3Q3eHO6wjbII5MBAaumh7b9gG2w1boRjuJJdlgiTi8PJbpoeag/DAYNgIxfAQnGnzGu0SuNOjX6H/CcpNlpqX/wP2ZYHaiV0zZQAAAABJRU5ErkJggg==) no-repeat;background-size:contain;}
                    .m-cnt{padding:0}
                    .btncolor{background:#AD2A26}
                `,
                // cssDomain: window.cacheUrl + '/css/',
                // cssFiles: 'login.css',
                // needQrLogin : 1,
                // toolName : "邮箱大师APP",
                // toolUrl : "http://mail.163.com/dashi/?from=urs",
                needAnimation: 1,
                single: 1,
                // placeholder : {account:'网易邮箱',pwd:'密码'},
                // regUrl : 'http://reg.email.163.com/unireg/call.do?cmd=register.entrance&from=one',
                // oauthLoginConfig : [
                //     {'name' : 'qq','url' : 'http://reg.163.com/outerLogin/oauth2/connect.do?target=1&product=pin&url=http%3A%2F%2F'+location.host+'&url2=http%3A%2F%2F'+location.host},
                //     {'name' : 'weixin','url' : 'http://reg.163.com/outerLogin/oauth2/connect.do?target=13&product=pin&url=http%3A%2F%2F'+location.host+'&url2=http%3A%2F%2F'+location.host},
                //     {'name' : 'weibo','url' : 'http://reg.163.com/outerLogin/oauth2/connect.do?target=3&product=pin&url=http%3A%2F%2F'+location.host+'&url2=http%3A%2F%2F'+location.host}
                // ],
                productkey: '7fa8dcb4f260148aacde223ef37604c8',
                // otherThirdLink: '<div class="m-ologin"><div class="otip f-fl">其他方式登录</div><div class="olist"><a class="f-cb f-fl third qq j-redirect" href="http://reg.163.com/outerLogin/oauth2/connect.do?target=1&product=pin&url=' + url+ '&url2=' + url + '" target="_parent"></a><a class="f-cb f-fl third weixin j-redirect" href="http://reg.163.com/outerLogin/oauth2/connect.do?target=13&product=pin&url=' + url + '&url2=' + url + '" target="_parent"></a><a class="f-cb f-fl third weibo j-redirect" href="http://reg.163.com/outerLogin/oauth2/connect.do?target=3&product=pin&url=' + url + '&url2=' + url + '" target="_parent"></a></div></div>'
                // terms : [
                //     { 'name' : '"服务条款"', 'url' : 'http://reg.163.com/agreement.shtml' },
                //     { 'name' : '"用户须知"', 'url' : 'http://reg.163.com/agreement.shtml' },
                //     { 'name' : '"隐私权相关政策"', 'url' : 'http://reg.163.com/agreement_game.shtml'}
                // ],
                // cssDomain : 'http://mimg.127.net/hd/all3/160526_urslogin/',
                // cssFiles : 'loginStyle.css'
            });

            urs.logincb = ()=>{
                window.__needReloadForLogin = true;
                history.replace(nextState.location);
            }

            // urs.showIframe();
        }
    }

    render(){
        return <div id="login" className="f-page login"></div>;
    }
}
module.exports = Login;