/**
 * 地址管理
 */
const React = require("react");
const {Link} = require("react-router");

const AddressItem = require('../subItem/addressItem');
const SlideOperations = require("../module/slideOperations");
const Msgbox = require('../module/msgbox');

const ShipAddressAction = require("pin-alt/src/actions/shipAddressAction");
const ShipAddressStore = require("pin-alt/src/stores/shipAddressStore");
const connectToStores = require("alt-utils/lib/connectToStores");
const WeixinUtil = require('../weixinUtil');
const MobileUtil = require('../mobileUtil');


class AddressList extends React.Component {

    constructor(props){
        super(props);

        this.state = {
            currentAddress: null,
            removeConfirm: null
        };

        ShipAddressAction.getShipAddressList();

        this.onEditClick = this.onEditClick.bind(this);
    }

    static getStores(){
        return [ShipAddressStore];
    }

    static getPropsFromStores(){
        return ShipAddressStore.getState();
    }

    onOperateClick(key, item){
        if(key == 'remove'){
            this.setState({
                removeConfirm: item
            });
        }
    }

    onEditClick(item){
        let history = this.props.history;
        history.pushState(null, '/address/edit/' + item._id);
    }

    onRemove(shipAddress){
        setTimeout(()=>{
            ShipAddressAction.removeShipAddress(shipAddress);
            ShipAddressAction.getShipAddressList();
        }, 0);
    }

    onItemClick(item){
        let history = this.props.history;
        let {goodsId, count, buyAlone, grouponId} = this.props.location.query;
        history.replaceState(null, '/groupon/create?goodsId=' + goodsId + '&count=' + count + '&addressId=' + item._id + (grouponId ? '&grouponId=' + grouponId : '') + (buyAlone ? '&buyAlone=true' : ''));
    }

    render(){
        let {shipAddressList, location, loading} = this.props;
        let isChoose = !!location.query.choose;

        return <div className="f-page address">
                    <div className="f-body fixedFooter">
                        <div className="address-list">
                            {(()=>{
                                if(shipAddressList.length > 0){
                                    return shipAddressList.map((item, n)=>{
                                        if(isChoose){
                                            return <AddressItem onClick={()=>{this.onItemClick(item)}}
                                                         onIconClick={()=>{this.onEditClick(item)}}
                                                         key={n}
                                                         address={item}
                                                         editable={true}/>
                                        }else{
                                            return <SlideOperations onClick={()=>{this.onEditClick(item)}} key={n} onOperate={(key)=>this.onOperateClick(key, item)} operations={{'remove': '删除'}}>
                                                <AddressItem address={item} editable={true}/>
                                            </SlideOperations>
                                        }
                                    })
                                }else{
                                    return <div className="w-no-content">
                                        <i className="i-no-addr"></i>
                                        <p className="no-p no-addr">您还没有收货地址</p>
                                    </div>
                                }
                            })()}
                        </div>
                    </div>
                    <div className="f-footer fixed">
                        {shipAddressList.length < 10 &&
                            (WeixinUtil.isWeixin() ? <div className="w-operation divided">
                                                        <Link className="main" to="/address/add">
                                                            <i className="i-add-white"></i> 手动添加
                                                        </Link>
                                                        <a className="main weixin" onClick={()=>{
                                                            WeixinUtil.init(()=>{
                                                                WeixinUtil.address(MobileUtil.getUserName(), (suc, res)=>{
                                                                    if(suc) {
                                                                        ShipAddressAction.syncShipAddress(res, ()=> {
                                                                            ShipAddressAction.getShipAddressList();
                                                                        });
                                                                    }
                                                                });
                                                            });
                                                        }} href="javascript:void(0);">
                                                            <i className="i-wx-white"></i> 微信添加
                                                        </a>
                                                    </div> :
                                                    <div className="w-operation divided">
                                                        <Link className="main" to="/address/add">
                                                            <i className="i-add-white"></i> 新建地址
                                                        </Link>
                                                    </div>)
                        }
                    </div>

                    {this.state.removeConfirm && <Msgbox
                        center={true}
                        title="确定删除地址？"
                        onOkClick={()=>{
                            this.onRemove(this.state.removeConfirm);
                            this.setState({
                                removeConfirm: null
                            })
                        }}
                        onCancelClick={()=>{
                            this.setState({
                                removeConfirm: null
                            })
                        }}
                    />}
                </div>;
    }
}



module.exports = connectToStores(AddressList);