"use strict"
const {Link} = require("react-router");
const React = require("react");
const moment = require("moment");
const util = require('pin-util/src/web_util');

const NumberInput = require('../module/numberInput');
const AddressPicker = require('../module/addressPicker');
const Msgbox = require('../module/msgbox');

const connectToStores = require("alt-utils/lib/connectToStores");
const SubmitOrderAction = require("pin-alt/src/actions/submitOrderAction");
const SubmitOrderStore = require("pin-alt/src/stores/submitOrderStore");
const GoodsAction = require("pin-alt/src/actions/goodsAction");
const GoodsStore = require("pin-alt/src/stores/goodsStore");
const MobileUtil = require("../mobileUtil");
const WeixinUtil = require("../weixinUtil");

class SubmitOrder extends React.Component{
    constructor(props) {
        super(props);

        let {count, addressId} = props.location.query;

        this.state = {
            count: count-0 || 1,
            addressId: addressId,
            submitTips: '',
            disableNumber: false
        };

        this.onCountChange = this.onCountChange.bind(this);
        this.onAddressChange = this.onAddressChange.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        SubmitOrderStore.listen(this.getListener());
    }

    static getStores(){
        return [GoodsStore, SubmitOrderStore];
    }

    static getPropsFromStores(){
        return {
            ...GoodsStore.getState(),
            ...SubmitOrderStore.getState()
        }
    }

    onSubmit(){
        let {createOrder, participateOrder, location, history} = this.props;
        let {goodsId, grouponId, buyAlone} = location.query;
        let {count, addressId} = this.state;

        if(!addressId){
            this.setState({
                submitTips: '请选择收货地址'
            });
            return;
        }

        // 如果已经有orderId
        let yxId = (createOrder || participateOrder || {}).yx_order_id;
        if(WeixinUtil.isWeixin() && yxId){
            SubmitOrderAction.wxPay(yxId);
        } else {

            if (buyAlone) {
                SubmitOrderAction.buyAlone(goodsId, addressId, count);
            } else {
                if (grouponId) {
                    SubmitOrderAction.participate(grouponId, addressId, count, null, goodsId);
                } else {
                    SubmitOrderAction.createGroupon(goodsId, addressId, count);
                }
            }

            this.setState({
                disableNumber: true
            });
        }
    }

    onAddressChange(id){
        // this.setState({addressId: id})
        this.state.addressId = id;
    }

    onCountChange(value){
        setTimeout(()=>this.setState({count: value}), 0);
    }

    componentWillUnmount(){
        SubmitOrderStore.unlisten(this.listener);
    }

    componentWillMount(){
        let {goodsId} = this.props.location.query;

        WeixinUtil.isWeixin() && WeixinUtil.init();
        GoodsAction.getDetail(goodsId);
    }

    pay(params){
        if(WeixinUtil.isWeixin()) {
            if (!params.wxPayError) {
                if (params.wxPay && params.wxPay.wxpay) {
                    MobileUtil.wxPay(this, params.wxPay.wxpay, (params.grouponId ? '/grouponDetail/' + params.grouponId : '/payResult') + '?orderId=' + params.yxId, ()=>{
                        this.props.history.replaceState(null, '/orderDetail/' + params.orderId);
                        // this.props.history.goBack();
                    });
                } else {
                    setTimeout(()=> {
                        SubmitOrderAction.wxPay(params.yxId);
                    }, 0);
                }
            }else{
                alert(params.wxPayError);
            }
        }else if (params.orderId) {
            MobileUtil.gotoPay(this, params.orderId);
        }
    }

    getListener(){
        return this.listener = (store)=>{
            let isParticipate = !!this.props.location.query.grouponId;
            let {wxPay, createOrder, participateOrder, wxPayError, submitErr} = store;

            let order = isParticipate ? participateOrder : createOrder;

            if(submitErr && submitErr.code){
                alert('提交失败，请稍候再试！');
                return;
            }

            if(!order){
                return;
            }

            let orderId = order._id;
            let yxId = order.yx_order_id;
            let grouponId = order.grouponId;

            if(orderId || yxId){
                this.pay({orderId, yxId, wxPay, wxPayError, grouponId});
            }else{
                alert('提交失败，请稍候再试！');
            }
        };
    }

    render(){
        let state = this.state;
        let {goodsId, buyAlone, addressId, grouponId} = this.props.location.query;
        let {goodsDetail, history}= this.props, goods;

        if(goodsDetail){
            goods = goodsDetail.goods;
        }else{
            return null;
        }

        let totalPrice = MobileUtil.getPriceDiscount(goods.mobilePrice, state.count);

        return <div className="f-page order">

                    <div className="f-body fixedFooter">

                        <div className="address">
                            <AddressPicker buyAlone={!!buyAlone} grouponId={grouponId} goodsId={goodsId} count={state.count} addressId={state.addressId} onDefault={this.onAddressChange} />
                        </div>

                        <div className="w-goods normal">
                            <div className="pic">
                                <img src={util.getImage(goods.image250, goods.imageToken, 'intro')} alt=""/>
                            </div>

                            <div className="info">
                                <h2>{goods.name}</h2>
                                <p>规格：{goods.skuDesc || goods.specification}</p>
                                {buyAlone ?
                                    <p className="t-str">
                                        <span className="w-price">￥{goods.yanPrice}</span>
                                    </p>
                                    :
                                    <p className="t-str">
                                        <span className="w-price">￥{goods.mobilePrice}</span>（包邮）
                                    </p>
                                }
                            </div>
                        </div>

                        <div className="bars">
                            <div className="w-bar bordered">购买数量
                                <div className="value">
                                    <NumberInput disabled={this.state.disableNumber} value={state.count} min={Math.min(1, goods.remain)} max={goods.isMega ? 1 : Math.min(5, goods.remain)} onChange={this.onCountChange} />
                                </div>
                            </div>

                            {buyAlone ?
                                <div className="w-bar">快递运费 <div className="value"><em className="t-str">￥{(MobileUtil.getYanShipPrice(goods.yanPrice, state.count, goods.yanShipPrice)).toFixed(2)}</em></div></div>
                                :
                                <div className="w-bar">优惠
                                    <div className="value t-aside">
                                        {
                                            (()=>{
                                                let count = state.count;
                                                let price = goods.mobilePrice * count;
                                                let newPrice = MobileUtil.getPriceDiscount(goods.mobilePrice, count);
                                                let nextCoupon = MobileUtil.getPriceDiscount(goods.mobilePrice, count+1) - goods.mobilePrice * (count+1);
                                                return newPrice < price ? <em className="t-str">￥{(price-newPrice).toFixed(2)}</em> : ('无优惠' + (nextCoupon ? '（多买更优惠）' : ''))
                                            })()
                                        }
                                    </div>
                                </div>
                            }
                        </div>

                        {WeixinUtil.isWeixin() &&
                            <div className="bars payments">
                                <div className="w-bar">支付方式 <span className="value t-aside"><i className="i-wxpay"></i> 微信支付</span></div>
                            </div>
                        }

                        {buyAlone &&
                            <div className="pinTips">
                                <h3>您真的不试试拼团购吗？</h3>
                                <p>
                                    该商品拼团购<em className="t-str">包邮</em>哦，<em className="t-str">共省{(MobileUtil.getYanPriceWithShip(goods.yanPrice, state.count, goods.yanShipPrice) - MobileUtil.getPriceDiscount(goods.mobilePrice, state.count)).toFixed(2)}</em>，
                                    <Link to={"/groupon/create/?goodsId=" + goodsId + "&count=" + state.count + "&addressId=" + addressId}>马上去拼团 &gt;&gt;</Link>
                                </p>
                            </div>
                        }

                    </div>

                    <div className="f-footer fixed">
                        <div className="w-submit">
                            <div className="info">
                                <p>实付款：
                                    {buyAlone ?
                                        <span className="price"><strong className="w-price">￥{MobileUtil.getYanPriceWithShip(goods.yanPrice, state.count, goods.yanShipPrice)}</strong></span>
                                        :
                                        <span className="price"><strong className="w-price">￥{totalPrice}</strong> 包邮</span>
                                    }
                                </p>
                                {/*<p>拼团节省：￥{(state.count*(goods.yanPrice+goods.yanShipPrice-goods.price)).toFixed(2)}</p>*/}
                            </div>
                            <a href="javascript:void(0);" onClick={state.count > 0 ? this.onSubmit:null} type="button" className="main">立即支付</a>
                        </div>
                    </div>

                    {this.state.submitTips && <Msgbox center={true} title={this.state.submitTips} onOkClick={()=>{
                        this.setState({submitTips: ''})
                    }}/>}
                </div>
    }
}
module.exports = connectToStores(SubmitOrder);