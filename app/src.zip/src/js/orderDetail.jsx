"use strict"
const React = require("react");
const {Link} = require("react-router");

const connectToStores = require("alt-utils/lib/connectToStores");

const MyOrderAction = require("pin-alt/src/actions/myOrderAction");
const OrderDetailStore = require("../store/orderDetailStore");

const SubmitOrderAction = require("pin-alt/src/actions/submitOrderAction");
const SubmitOrderStore = require("pin-alt/src/stores/submitOrderStore");

const GoodsAction = require("pin-alt/src/actions/goodsAction");
const GoodsStore = require("../store/goodsStore");

const util = require('pin-util/src/web_util');
const OrderStatus = require("pin-data/enum/orderStatus");
const payMethod = require("pin-data/dicts/payMethod");
const moment = require("moment");
const Msgbox = require("../module/msgbox");
const MobileUtil = require("../mobileUtil");
const WeixinUtil = require("../weixinUtil");
const Recommend = require("../module/recommend");

const StatusText = {
    "notPayed": "等待买家支付",
    "payed": "拼团还未成功<br/>赶快让小伙伴们都来拼团吧~",
    "success": "组团成功 <br/>等待发货中...",
    "fail": "组团失败",
    "delete": "订单已取消",
    "invalid": "订单付款超时",
    "payedfail": "支付失败",
    "delivered": "已发货",
    "received": "交易完成",
    "cancel": "订单已取消",
    "kfCancel":"客服已取消订单",
    "refunded":"已退款"
};
class OrderDetail extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            confirmDialogVisible : false,
            confirmText : '',
            confirm: null,
            paying:true,
        }
        this.listener = (store) => {
            let gid = store.order.goods._id;
            GoodsAction.getRecommends(gid);
        }
        OrderDetailStore.listen(this.listener);

    }
    componentWillUnmount(){
        OrderDetailStore.unlisten(this.listener);
    }

    static getStores() {
        return [
            OrderDetailStore,
            SubmitOrderStore,
            GoodsStore
        ];
    }

    static getPropsFromStores() {
        return {
            ...OrderDetailStore.getState(),
            ...SubmitOrderStore.getState(),
            ...GoodsStore.getState()
        };
    }

    componentWillMount(){
        MyOrderAction.getOrderInfo(this.props.params.orderId);

    }

    showGroup(grouponId){
        let history = this.props.history;
        history.pushState(null, '/grouponDetail/' + grouponId);
    }

    showDelivery(order){
        let history = this.props.history;
        history.pushState(null, '/delivery/' + order._id);
    }

    goodsDetail(good){
        let history = this.props.history;
        history.pushState(null, '/goodsDetail/' + good._id);
    }
    // //修改取消订单弹框状态
    changeConfirmVisible() {
        this.setState({
            confirmDialogVisible : !this.state.confirmDialogVisible
        })
    }

    //确认收货
    confirmReceive(order){
        this.setState({
            confirmDialogVisible:true,
            confirmText:"确认收货？",
            confirm:()=>{
                MyOrderAction.confirmOrder(order._id);
            }
        });
    }

    //取消订单
    cancelOrder(order){
        this.setState({
            confirmDialogVisible:true,
            confirmText:"取消订单？",
            confirm:()=>{
                MyOrderAction.cancelOrder(order._id);
            }
        });
    }

    goPay(order){
        let orderId = order._id,
            yxId = order.yx_order_id;
        if(orderId || yxId){
            if(WeixinUtil.isWeixin()) {
                SubmitOrderAction.wxPay(yxId);
            }else if (orderId) {
                MobileUtil.gotoPay(this, orderId);
            }
            this.setState({paying:true});
        }
    }

    componentDidUpdate(){

        let {wxPay, wxPayError,grouponId,order} = this.props;
        if(!order){
            return;
        }
        let orderId = order._id;
        let yxId = order.yx_order_id;
        if(orderId || yxId ){
            if(WeixinUtil.isWeixin() && wxPay) {
                if (!wxPayError) {
                    if (wxPay.wxpay && order != null && this.state.paying) {
                        MobileUtil.wxPay(this, wxPay.wxpay, (grouponId ? '/grouponDetail/' + grouponId : '/payResult') + '?orderId=' + yxId);
                        this.setState({paying:false});
                    }
                }
            }
        }else{
            alert('提交失败，请稍候再试！');
        }
    }

    render() {
        let {order,grouponId,groupQuota,recommends} = this.props;

        if (!order) {
            return null;
        }

        let {goods,delivery,payResult,shipAddress} = order,
            addr = shipAddress.province.name + shipAddress.city.name + shipAddress.district.name + shipAddress.address;

        //优惠
        let price = (goods.yanPrice * order.count) >= 88 ?
                        goods.yanPrice * order.count :
                        goods.yanPrice * order.count + goods.yanShipPrice ;

        let favorable = 0;
        if(payResult){
            favorable = price - payResult.tradeAmount;
        }

        let statusClass = '', text;

        //团?
        let joinWay = true ;
        if(groupQuota && groupQuota == 1){
            joinWay = false;
        }
        switch (order.status) {
            case OrderStatus.DELETED:
                text = StatusText["delete"];
                statusClass = "t-err";
                break;
            case OrderStatus.PAY_FAILED:
                text = StatusText["payedfail"];
                statusClass = "t-err";
                break;
            case OrderStatus.FAILED:
                text = StatusText["fail"];
                statusClass = "t-err";
                break;
            case OrderStatus.NOT_PAYED:
                text = (joinWay? StatusText["notPayed"] : "等待买家支付");
                statusClass = "t-warning";
                break;
            case OrderStatus.PAYED:
                text = (joinWay? StatusText["payed"]: "已支付");
                statusClass = "t-warning";
                break;
            case OrderStatus.SUCCESS:
                text = (joinWay? StatusText["success"]: "等待发货中...");
                statusClass = "t-suc";
                break;
            case OrderStatus.DELIVERED:
                text = StatusText["delivered"];
                statusClass = "t-suc";
                break;
            case OrderStatus.INVALID:
                text = StatusText["invalid"];
                statusClass = "t-err";
                break;
            case OrderStatus.RECEIVED:
                text = StatusText["received"];
                statusClass = "t-suc";
                break;
            case OrderStatus.FAILED:
                text = StatusText["fail"];
                statusClass = "t-err";
                break;
            case OrderStatus.CANCEL:
                text = StatusText["cancel"];
                statusClass = "t-err";
                break;
            case OrderStatus.KF_CANCEL:
                text = StatusText["kfCancel"];
                statusClass = "t-err";
                break;
            case OrderStatus.REFUNDED:
                text = StatusText["refunded"];
                statusClass = "t-err";
                break;
        }

        return <div className="f-page orderDatail">

            <div className="orderStatus" dangerouslySetInnerHTML={{__html: text}}>
                {/*{text}*/}
            </div>

            {/*addr-msg*/}
            <div className="w-address">
                <div className="w-address-icon">
                    <i className="i-addr-active"></i>
                </div>
                <div className="w-address-main">
                    <div className="w-address-msg">
                        <div className="w-address-name">{shipAddress.name}</div>
                        <div className="w-address-tel">{shipAddress.mobile}</div>
                    </div>
                    <div className="w-address-ad">{addr}</div>
                </div>
            </div>

            {/*goods-msg*/}
            <div className="order-content">
                <div className="content">
                    <div className="order-img">
                        <img className="comment-picture"
                             src={util.getImage(goods.image250, goods.imageToken, 'intro')}
                             alt={goods.name}
                             width="100%"
                             onClick={()=>{this.goodsDetail(order.goods)}}/>
                    </div>
                    <div className="order-p">
                        <div className="good-name"
                             onClick={()=>{this.goodsDetail(order.goods)}}>{goods.name}</div>

                        <div className="gray">{goods.specification}</div>
                        <div className="gray">数量: {order.count || 1}</div>
                        <div className="red">
                            <span className="price">¥ {order.price} </span>
                            <span>{joinWay || order.shipPrice == 0 ? '包邮' : '+ ' + order.shipPrice + ' 邮费'} </span>
                        </div>
                    </div>
                </div>


                {joinWay ?
                    [OrderStatus.SUCCESS,OrderStatus.DELIVERED,OrderStatus.PAYED,OrderStatus.RECEIVED].indexOf(order.status) > -1 ?
                    <div>
                        <div className="line"></div>
                        <div className="content-btn">
                            <button className="aside"
                                    onClick={()=>{this.showGroup(grouponId);}}>
                                    查看团详情
                            </button>
                        </div>
                    </div>
                    : null
                 :null
                }
            </div>

            <div className="order-msg">
                <div className="order-p">
                    <p>
                        <span className="gray">订单编号: </span>
                        {order.yx_order_id}
                    </p>
                    <p>
                        <span className="gray">下单时间: </span>
                        {moment(order.create_time).format('YYYY-MM-DD HH:mm:ss')}
                    </p>

                </div>

                <div className="pay-msg">
                    {[OrderStatus.PAYED, OrderStatus.SUCCESS, OrderStatus.RECEIVED, OrderStatus.DELIVERED ,OrderStatus.REFUNDED].indexOf(order.status) > -1 ?
                        <div>
                            <p>
                                <span className="gray">支付方式: </span>
                                <span>{payMethod[payResult.payMethod]}</span>
                            </p>
                            <p>
                                <span className="gray">付款时间: </span>
                                {moment(payResult.payTime).format('YYYY-MM-DD HH:mm:ss')}
                            </p>
                            {joinWay ?
                                <p>
                                    <span className="gray">拼团优惠: </span>
                                    ¥ {favorable}
                                </p>
                                :
                                null
                            }

                            <p>
                                <span className="gray">物流运费: </span>
                                ¥ { order.shipPrice }
                            </p>
                            <p>
                                <span className="gray">支付总额: </span>
                                <span className="red">
                                ¥ {payResult.tradeAmount ||Math.round( (order.price + order.shipPrice)*100)/100}
                            </span>
                            </p>
                        </div>
                        : null}

                    {[OrderStatus.RECEIVED, OrderStatus.DELIVERED].indexOf(order.status) > -1 ?
                        <div>
                            {delivery.content.length > 0 ?
                                <p>
                                <span className="gray">发货时间: </span>
                                {moment(delivery.content[delivery.content.length-1].time).format('YYYY-MM-DD HH:mm:ss')}
                                </p>
                                :null
                            }

                            <p>
                                <span className="gray">快递方式: </span>
                                {delivery.company}
                            </p>
                            <p>
                                <span className="gray">快递编号: </span>
                                {delivery.number}
                            </p>
                        </div>
                        : null}
                </div>
            </div>



            {[OrderStatus.SUCCESS].indexOf(order.status) > -1 ?
                <div className="tips">温馨提示，如想取消订单，请拨打400-0368-163，有专属客服帮您处理。</div> : null}

            <Recommend items={recommends}/>

            {this.state.confirmDialogVisible &&
            <Msgbox
                center={true}
                title={this.state.confirmText}
                onOkClick={()=>{
                    if(this.state.confirm){
                        this.state.confirm();
                    }
                    this.setState({
                        confirmDialogVisible: false,
                        confirmText:null,
                        confirm:null
                    })
                }}
                onCancelClick={()=>{
                    this.setState({
                        confirmDialogVisible: false,
                        confirmText:null,
                        confirm:null
                    })
                }}
            />
            }


            {[OrderStatus.NOT_PAYED,OrderStatus.DELIVERED,OrderStatus.RECEIVED].indexOf(order.status) > -1 ?
                <div className="f-footer fixed shadowed">
                    <div className="list-detail">
                    <span className="btns">

                        {[OrderStatus.NOT_PAYED].indexOf(order.status) > -1 ?
                            <button className="aside"
                                    onClick={()=>{this.cancelOrder(order)}}>
                                取消订单</button> : ""}

                        {[OrderStatus.NOT_PAYED].indexOf(order.status) > -1 ?
                            <button className=""
                                    onClick={()=>{this.goPay(order);}}>
                                去支付</button> : ""}

                        {[OrderStatus.DELIVERED,OrderStatus.RECEIVED].indexOf(order.status) > -1 ?
                            <button className="aside"
                                    onClick={()=>{this.showDelivery(order);}}>
                                查看物流</button> : ""}

                        {[OrderStatus.DELIVERED].indexOf(order.status) > -1?
                            <button className=""
                                    onClick={()=>{this.confirmReceive(order);}}>
                                确认收货</button> : ""}
                        </span>
                    </div>
                </div>
                : null}


        </div>;
    }
}


module.exports = connectToStores(OrderDetail);
