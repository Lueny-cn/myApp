"use strict"
const React = require("react");
const LOCAL_KEY = 'redirect';

class Redirect extends React.Component{

    getLocal(){
        try{
            return JSON.parse(localStorage.getItem(LOCAL_KEY));
        }catch(e){}
    }

    removeLocal(){
        try{
            return localStorage.removeItem(LOCAL_KEY);
        }catch(e){}
    }

    componentWillMount(){
        let nextState = this.getLocal();
        let history = this.props.history;

        $.ajax({
            url: '/api/weixin/openid'
        });
        if(nextState) {
            history.replace(nextState.location);
        }else{
            history.replaceState({}, '/');
        }
        this.removeLocal();
    }

    render(){
        return <div></div>;
    }
}
module.exports = Redirect;