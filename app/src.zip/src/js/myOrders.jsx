"use strict"
const React = require("react");

const connectToStores = require("alt-utils/lib/connectToStores");
const MyOrderAction = require("pin-alt/src/actions/myOrderAction");
const MyOrderStore = require("pin-alt/src/stores/myOrderStore");
const OrderItem = require("../subItem/orderItem");
const Tabs = require("../module/tabs");
const WeixinUtil = require("../weixinUtil");
const Nav = require("../module/nav");

const SubmitOrderAction = require("pin-alt/src/actions/submitOrderAction");
const SubmitOrderStore = require("pin-alt/src/stores/submitOrderStore");

const PersonalAction = require("pin-alt/src/actions/personalAction");
const PersonalStore = require("pin-alt/src/stores/personalStore");
const MobileUtil = require("../mobileUtil");
const Msgbox = require("../module/msgbox");


const GTYPE = {
    ALL: 0,
    NOTPAYED: 1,
    NOTRECEIVED: 2,
    RECEIVED: 3,
    PINING: 4
}
class MyOrders extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            currentYxPayOrder: null,
            loading: false,
            currentType: this.getQueryString('showType') - 0 || GTYPE.ALL,
            start: 0,
            size: 10,
            ifClick:false
        };
        this.scrollHandler = this.scrollHandler.bind(this);
        this.listener = (store) => {

            if(store.unpaidedOrderCount - 0 > 0 && this.getQueryString('showType') - 0 == 0){

                MyOrderAction.getOrders(GTYPE.NOTPAYED, this.state.start, this.state.size);
            }else{
                MyOrderAction.getOrders(this.state.currentType, this.state.start, this.state.size);

            }

        }
        PersonalStore.listen(this.listener);

    }



    componentWillMount() {
        window.addEventListener("scroll", this.scrollHandler, false);
        WeixinUtil.isWeixin() && WeixinUtil.init();
        PersonalAction.getUnpaidOrders();
        PersonalAction.getStartingGroupons();
        PersonalAction.getReadyReceiveOrders();
    }
    componentDidMount(){
        //找到原来的tab
        let that = this,
            history = this.props.history;
        if (window.history && window.history.pushState) {
            window.addEventListener('popstate', function () {
                var hash = window.location.hash;
                if (/myOrders/.test(hash) && !/showType/.test(hash) ) {
                    history.pushState( null, '/myOrders?showType=' + (that.getQueryString('showType') - 0 || GTYPE.ALL));
                }
            });
        }
    }

    componentWillUnmount() {
        window.removeEventListener("scroll", this.scrollHandler, false);
        PersonalStore.unlisten(this.listener);
    }

    static getStores() {
        return [
            MyOrderStore,
            SubmitOrderStore,
            PersonalStore
        ];
    }

    static getPropsFromStores() {
        return {
            ...MyOrderStore.getState(),
            ...SubmitOrderStore.getState(),
            ...PersonalStore.getState()
        };
    }

    getQueryString(name) {
        var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
        var r = this.props.location.search.substr(1).match(reg);
        if (r != null) {
            return r[2];
        }
        return null;
    }

    showType(nType) {
        this.setState({currentType: nType, start: 0, size: 10, loading: true});
        MyOrderAction.getOrders(nType, 0, 10);
    }

    showMore() {
        let {currentType, start, size, loading} = this.state;
        let {hasMore} = this.props;
        if (!this.props.loading && hasMore) {
            if (this.state.start !== start + size) {
                this.setState({start: start + size, loading: true});
                MyOrderAction.getOrders(currentType, start + size, size);
            }
        }
    }

    goPay(order) {
        let orderId = order._id,
            yxId = order.yx_order_id;
        if (orderId || yxId) {
            if (WeixinUtil.isWeixin()) {
                SubmitOrderAction.wxPay(yxId);
            } else if (orderId) {
                MobileUtil.gotoPay(this, orderId);
            }
            this.setState({currentYxPayOrder: order});
        }
    }

    //确认收货
    confirmReceive(order) {
        this.setState({
            confirmDialogVisible: true,
            confirmText: "确认收货？",
            confirm: ()=> {
                MyOrderAction.confirmOrder(order._id);
            }
        });
    }

    //取消订单
    cancelOrder(order) {
        this.setState({
            confirmDialogVisible: true,
            confirmText: "是否取消此订单？",
            confirm: ()=> {
                MyOrderAction.cancelOrder(order._id);
            }
        });
    }
    //查看订单详情
    showOrder(order){
        let history = this.props.history;
        history.pushState(null, '/orderDetail/' + order._id + '?showType =' + this.state.currentType);
    }

    componentDidUpdate() {
        let {wxPay, wxPayError} = this.props;
        let order = this.state.currentYxPayOrder;
        if (!order) {
            return;
        }
        let orderId = order._id;
        let yxId = order.yx_order_id;
        if (orderId || yxId) {
            if (WeixinUtil.isWeixin() && wxPay) {
                if (!wxPayError) {
                    if (wxPay.wxpay && order != null) {
                        MobileUtil.wxPay(this, wxPay.wxpay, '/grouponDetail/' + order.grouponId);
                        this.setState({currentYxPayOrder: null});
                    }
                }
            }
        } else {
            alert('提交失败，请稍候再试！');
        }
    }



    scrollHandler(e) {
        const container = this.refs["container"];
        let position = container.offsetTop + container.offsetHeight;

        if ($(window).scrollTop() + $(window).height() > position) {

            if (window.requestAnimationFrame) {
                window.requestAnimationFrame(this.showMore.bind(this));
            } else {
                setTimeout(this.showMore.bind(this), 60);
            }
        }
    }


    render() {
        // console.log(this.props);
        let {OrdersList,unpaidedOrderCount,readyReceiveOrdersCount,startingGrouponCount} = this.props,
            history = this.props.history,
            noPayOrder = unpaidedOrderCount - 0,
            noReceipt = readyReceiveOrdersCount - 0,
            received = 0,
            pining = startingGrouponCount,
            nType = 0,
            activeNum = 0;
        console.log(pining);
        const {currentType, loading} = this.state;
        let {ifClick} = this.state;

        if (!OrdersList) {
            return null;
        }
        let orderMain;
        if (OrdersList.length > 0) {

            orderMain = OrdersList.map((order, nIndex) => {
                return <OrderItem order={order}
                                  key={nIndex}
                                  history={this.props.history}
                                  goPay={this.goPay.bind(this)}
                                  showOrder={this.showOrder.bind(this)}
                                  cancelOrder={this.cancelOrder.bind(this)}
                                  confirmReceive={this.confirmReceive.bind(this)}/>;

            })
        } else {
            orderMain = (
                <div className="w-no-content">
                    <i className="i-no-order"></i>
                    <p className="no-p">您还没有订单</p>
                </div>
            )
        }
        if(noPayOrder - 0 > 0 && this.getQueryString('showType') - 0 == 0 && OrdersList.length && !ifClick){
            activeNum = 1;

        }else{
            if(this.state.currentType == 4){
                activeNum = 2;
            }else if(this.state.currentType == 2){
                activeNum = 3;
            }else if(this.state.currentType == 1){
                activeNum = 1;
            }else if(this.state.currentType == 3){
                activeNum = 4;
            }else{
                    activeNum = this.state.currentType;
                }
            }

        return <div className="f-page orderList" ref="container">

            <div className="f-header fixed">
                <Tabs items={[
                    {text: "全部", tip: 0},
                    {text: "待付款", tip: noPayOrder},
                    {text: "拼团中", tip: pining},
                    {text: "待收货", tip: noReceipt},
                    {text: "已签收", tip: received}
                ]}
                      notice="true"
                      active={activeNum}
                      onChange={(nType)=> {
                          this.state.ifClick = true;
                          switch (nType) {
                              case 2:
                                  this.showType(4);
                                  history.pushState(null, '/myOrders?showType=4');
                                  break;
                              case 3:
                                  this.showType(2);
                                  history.pushState(null, '/myOrders?showType=2');
                                  break;
                              case 4:
                                  this.showType(3);
                                  history.pushState(null, '/myOrders?showType=3');
                                  break;
                              default:
                                  this.showType(nType);
                                  history.pushState(null, '/myOrders?showType='+nType);
                                  break;
                          }
                      }}/>
            </div>
            <div className="order-list">
                {orderMain}
            </div>
            <div className="f-footer fixed">
                <Nav activeOn={2}/>
            </div>
            {this.state.confirmDialogVisible &&
            <Msgbox
                center={true}
                title={this.state.confirmText}
                onOkClick={()=> {
                    if (this.state.confirm) {
                        this.state.confirm();
                    }
                    this.setState({
                        confirmDialogVisible: false,
                        confirmText: null,
                        confirm: null
                    })
                }}
                onCancelClick={()=> {
                    this.setState({
                        confirmDialogVisible: false,
                        confirmText: null,
                        confirm: null
                    })
                }}
            />
            }
        </div>;
    }
}
module.exports = connectToStores(MyOrders);