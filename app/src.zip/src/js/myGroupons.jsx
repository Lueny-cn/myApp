"use strict"
const React = require("react");

const connectToStores = require("alt-utils/lib/connectToStores");
const MyGrouponAction = require("pin-alt/src/actions/myGrouponAction");
const MyGrouponStore = require("pin-alt/src/stores/myGrouponStore");
const GrouponItem = require("../subItem/grouponItem");
const Tabs = require("../module/tabs");
const Nav = require("../module/nav");
const PersonalAction = require("pin-alt/src/actions/personalAction");
const PersonalStore = require("pin-alt/src/stores/personalStore");

const GTYPE = {
    ALL: 0,
    CREATE: 1,
    PARTICIPATE: 2,
    STARTING: 3,
    SUCCESS: 4
};

class MyGroupons extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            currentType: this.getQueryString('showType') - 0 || GTYPE.ALL,
            start: 0,
            size: 10
        };
        this.scrollHandler = this.scrollHandler.bind(this);
        MyGrouponAction.getGroupons(this.state.currentType, this.state.start, this.state.size);
    }

    static getStores() {
        return [
            MyGrouponStore,
            PersonalStore
        ];
    }

    static getPropsFromStores() {
        return {
            ...MyGrouponStore.getState(),
            ...PersonalStore.getState()
        }
    }

    //获取地址栏参数
    getQueryString(name) {
        var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
        var r = this.props.location.search.substr(1).match(reg);
        if (r != null) {
            return r[2];
        }
        return null;
    }

    showType(nType) {
        this.setState({currentType: nType, start: 0, size: 10, loading: true});
        MyGrouponAction.getGroupons(nType, 0, 10);
    }

    componentWillMount() {
        window.addEventListener("scroll", this.scrollHandler, false);
        PersonalAction.getStartingGroupons();
    }

    componentWillUnmount() {
        window.removeEventListener("scroll", this.scrollHandler, false);
    }

    componentDidMount() {
        //找到原来的tab
        let that = this,
            history = this.props.history;

        if (window.history && window.history.pushState) {
            window.addEventListener('popstate', function () {
                var hash = window.location.hash;
                if (/myGroupons/.test(hash) && !/showType/.test(hash)) {
                    history.pushState(null, '/myGroupons?showType=' + (that.getQueryString('showType') - 0 || GTYPE.ALL));
                }
            });
        }
    }

    showMore() {
        let {currentType, start, size, loading} = this.state;
        let {hasMore} = this.props;
        if (!this.props.loading && hasMore) {
            if (this.state.start !== start + size) {
                this.setState({start: start + size, loading: true});
                MyGrouponAction.getGroupons(currentType, start + size, size);
            }
        }
    }

    scrollHandler(e) {
        const container = this.refs["container"];
        let position = container.offsetTop + container.offsetHeight;

        if ($(window).scrollTop() + $(window).height() > position) {
            if (window.requestAnimationFrame) {
                window.requestAnimationFrame(this.showMore.bind(this));
            } else {
                setTimeout(this.showMore.bind(this), 60);
            }
        }
    }

    showOrder(order) {
        let history = this.props.history;
        history.pushState(null, '/orderDetail/' + order._id);
    }

    showGroupon(groupon) {
        let history = this.props.history;
        history.pushState(null, '/grouponDetail/' + groupon._id);
    }

    goodsDetail(good) {
        let history = this.props.history;
        history.pushState(null, '/goodsDetail/' + good._id);
    }

    render() {
        let {GrouponsList} = this.props,
            startingGrouponCount = this.props.startingGrouponCount,
            groupMain,
            active,
            history = this.props.history;
        const {currentType, loading} = this.state;
        if (!GrouponsList) {
            return null;
        }
        if (GrouponsList.length !== 0) {
            groupMain = GrouponsList.map((groupon, nIndex) => {

                return <GrouponItem groupon={groupon}
                                    key={nIndex} history={this.props.history}
                                    showOrder={this.showOrder.bind(this)}
                                    showGroupon={this.showGroupon.bind(this)}
                                    goodsDetail={this.goodsDetail.bind(this)}/>;
            })
        } else {
            groupMain = (
                <div className="w-no-content">
                    <i className="i-no-group"></i>
                    <p className="no-p">您还没有团</p>
                </div>
            )
        }
        switch (currentType) {
            case 3:
                active = 1;
                break;
            case 4:
                active = 2;
                break;
            default:
                active = currentType;
                break;
        }

        return <div className="f-page userGroup" ref="container">
            <div className="f-header fixed">
                <Tabs items={[
                    {text: "全部团"},
                    {text: "进行中的团", tip: startingGrouponCount},
                    {text: "已成功的团"}
                ]}
                      active={active}
                      notice='true'
                      onChange={(nType)=> {
                          let type = nType;
                          if (nType == 1) {
                              type = GTYPE.STARTING;
                              history.pushState(null, '/myGroupons?showType=3');
                          } else if (nType == 2) {
                              type = GTYPE.SUCCESS;
                              history.pushState(null, '/myGroupons?showType=4');
                          }
                          this.showType(type);

                      }}/>
            </div>
            <div className="group-list">
                {groupMain}
            </div>
            <div className="f-footer fixed">
                <Nav activeOn={1}/>
            </div>
        </div>;
    }
}
module.exports = connectToStores(MyGroupons);