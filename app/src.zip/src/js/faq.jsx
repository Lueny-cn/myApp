"use strict";
const React = require("react");

class Faq extends React.Component{

    render(){

        return <div className="w-faq">
            <iframe width="100%" height="4200px" src="http://mail.163.com/html/pin/faq_yanxuan.htm" scrolling="no"></iframe>
                </div>;
    }
}

module.exports =  Faq;