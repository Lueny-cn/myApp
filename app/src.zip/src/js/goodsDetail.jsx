"use strict"
const React = require("react");
const SlideShow = require("../module/slideshow");
const Bar = require("../module/bar");
const Recommend = require("../module/recommend");
const {Link} = require("react-router");
const Help = require("../module/help");
const Shortcuts = require("../module/shortcuts");
const Operation = require("../module/operation");
const Faq = require("../module/faq");
const Report = require("../module/report");
const Panels = require("../module/panels");
const Detail = require("../module/detail");
const Comments = require("../module/comments");
const ShareTips = require("../module/shareTips");
const ChooseSku = require("../module/chooseSku");
const OtherGroup = require("../module/otherGroup");
const Gallery = require("../module/gallery");
const CommentItem = require("../subItem/commentItem");

const WeixinUtil = require("../weixinUtil");
const MobileUtil = require("../mobileUtil");

const connectToStores = require("alt-utils/lib/connectToStores");
const GoodsAction = require("pin-alt/src/actions/goodsAction");
const GoodsStore = require("../store/goodsStore");

const util = require('pin-util/src/web_util');
const Flux = require("pin-alt/src/flux");

class GoodsDetail extends React.Component{
    constructor(props) {
        super(props);

        this.state = {
            showDetail: false,
            showShareTips: false,
            showImage: false
        };

        this.onTouchMove = this.onTouchMove.bind(this);
        this.onScroll = this.onScroll.bind(this);
        this.onShare = this.onShare.bind(this);
        this.onShareLayerClick = this.onShareLayerClick.bind(this);


        this.key = this.props.location.key;
    }

    static getStores(){
        return [GoodsStore];
    }

    static getPropsFromStores(){
        return GoodsStore.getState();
    }

    componentWillUnmount(){
        window.removeEventListener('scroll', this.onScroll);
    }

    componentWillMount(){
        let gid = this.props.params.goodsId;
        GoodsAction.getDetail(gid);
        GoodsAction.getComments(gid, {start: 0}, '');
        GoodsAction.getRecommends(gid);
        window.scrollTo(0,0);
        window.addEventListener('scroll', this.onScroll);
        // window.addEventListener('touchmove', this.onTouchMove);

        WeixinUtil.isWeixin() && WeixinUtil.init();
    }

    showDetail(){
        this.setState({
           showDetail: true
        });
    }

    onTouchMove(e){
        e.stopPropagation();
    }

    onShare(){
        this.setState({
            showShareTips: true
        });
    }

    onShareLayerClick(){
        this.setState({
            showShareTips: false
        });
    }

    onScroll(){
        let body = document.body;
        let doc = document.documentElement;
        let max = doc.scrollHeight - doc.clientHeight;
        let top = body.scrollTop;

        if (!this.props.loading && (top >= max || max < 0)) {
            // 显示详情
            if (!this.state.showDetail) {
                this.showDetail();
            }

            // 评论翻页
            if (this.refs.comments) {
                let gid = this.props.params.goodsId;
                let {page, size, totalPage} = this.props.pagination;

                if (top >= max && page < Math.min(totalPage, 5)) {
                    GoodsAction.getComments(gid, {start: page * size}, '');
                }
            }
        }
    }

    getDetail(){
        let {goodsDetail, comments, recommends, pagination} = this.props;
        let goods = goodsDetail.goods;
        let hasComment = comments && comments.length > 0;
        let commentCount = (pagination && pagination.allTotal) || 0;

        if(this.state.showDetail){
            return <div ref="detail">
                <Panels autoFixed={true}>
                    <div tab="商品详情">
                        <Detail goods={goods}/>
                        <Report goods={goods} />
                        <Faq />
                        <Recommend items={recommends}/>
                        {/*<Help />*/}
                    </div>
                    <Comments ref="comments" tab="全部评论" badge={commentCount} comments={comments}/>
                </Panels>
            </div>
        }else{
            return <div>
                {hasComment && <div className="lastComment">
                    {
                        (()=>{
                            return <div className="w-bar bordered multi">
                                评论（{commentCount}）
                                <CommentItem comment={comments[0]}/>
                            </div>
                        })()
                    }
                </div>}
                <div className="pullUp">
                    <p>上拉加载更多详情</p>
                    <i className="i-pullUp"></i>
                </div>
            </div>
        }
    }

    render(){
        let state = this.state, goods;
        let {goodsDetail, params, location} = this.props;
        if(goodsDetail){
            goods = goodsDetail.goods;
        }
        if(!goods) {return null;}

        if(location.key !== this.key && !location.query.sku){
            window.location.reload();
            return null;
        }

        let token = goods.imageToken;

        let images = goods.introImages.map((item)=>{
            return {
                img: util.getImage(item.bigUrl.indexOf("http")>-1?item.bigUrl:'430_' + item.bigUrl, token, 'intro')
            }
        });

        if(WeixinUtil.isWeixin()) {
            let shareConfig = {
                title: goods.name, // 分享标题
                desc: goods.shareTextMobile, // 分享描述
                link: window.location.href, // 分享链接
                imgUrl: images[0].img, // 分享图标
                dataUrl: ''
            };

            WeixinUtil.setShare(shareConfig);
        }

        return <div className="f-page detail">
                    <div className="f-header fixed" hidden>
                    </div>

                    <div className="f-body fixedFooter">
                        <SlideShow items={images} onClick={()=>{this.setState({showImage:true})}}/>

                        <div className="info">
                            <div className="price_sale">
                                <p className="price"><strong className="w-price">¥ {goods.isMega ? '?' : goods.mobilePrice}</strong> 包邮</p>
                                <p className="original"> ¥ {goods.yanPrice + goods.yanShipPrice}</p>
                                <p className="hasSale">累计销量：{goods.sellCount > 0 ? goods.sellCount : 0}</p>
                            </div>
                            <div className="name_area">
                                {goods.productArea && <span className="w-label">{goods.productArea}</span>}
                                <span className="title">{goods.name}</span>
                            </div>

                            <p>{goods.desc}</p>

                            <ul className="advantage">
                                <li><i className="i-tick"></i>30天无忧退货</li>
                                <li><i className="i-tick"></i>全场免邮费</li>
                                <li><i className="i-tick"></i>网易品质保证</li>
                            </ul>
                        </div>

                        <p className="help">开团并邀请{goods.groupQuota}人参加，组团成功立即发货，详见<Link to="/help" className="more">拼团玩法</Link></p>

                        {goods.isMega ? null : <Bar text="请选择规格数量" next={true} to={"/goodsDetail/" + params.goodsId + "?sku=" + params.goodsId}/>}
                        {/*<Bar text="评论" next={true}/>*/}

                        {!goods.isMega && goodsDetail.groupons.length > 0 ? <OtherGroup items={goodsDetail.groupons} goods={goods} /> : null}

                        {this.getDetail()}

                    </div>

                    <div className="f-footer fixed">
                        <Operation goodsId={params.goodsId} goods={goods} buyAble={goodsDetail.buyAble} needSku={true}/>
                        <Shortcuts />
                    </div>

                    {state.showShareTips && <ShareTips onClick={this.onShareLayerClick} />}

                    {goods.isMega ? null : <ChooseSku hidden={!location.query.sku} {...this.props} />}

                    {state.showImage && <Gallery items={images} onClick={()=>{this.setState({showImage:false})}}/>}
                </div>;
    }
}

module.exports = connectToStores(GoodsDetail);