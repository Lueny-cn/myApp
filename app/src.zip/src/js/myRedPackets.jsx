"use strict";
const React = require("react");
const PacketItem = require("../subItem/packetItem");
// const connectToStores = require("alt-utils/lib/connectToStores");

const Tabs = require("../module/tabs");

class RedPacket extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            confirmDialogVisible: true,
            confirmText: "恭喜你获得了1元红包",
            confirm: null
        };
    }


    render() {
        let activeNum = 0;

        return <div className="f-page redPacket">

            <div className="f-header fixed">
                <Tabs items={[
                    {text: "可用红包", tip: 0},
                    {text: "已使用", tip: 0},
                    {text: "已失效", tip: 0}
                ]}
                      notice="true"
                      active={activeNum}
                      onChange={(nType)=> {
                              activeNum = nType;
                      }}
                      />
            </div>

            <div className="main">
                <PacketItem num={100}
                            time = "2016.06.24-2016.12.15"
                            intro = "全场通用，开团参与均可可以可以"
                            type = "新手红包"
                />
                <PacketItem/>

                {/*<div className="w-no-content">*/}
                    {/*<i className="i-no-redPacket"></i>*/}
                    {/*<p className="no-p">您还没有红包</p>*/}
                {/*</div>*/}

            </div>

        </div>;
    }
}
module.exports = RedPacket;