/**
 * Created by Zyingying on 2016/10/27 0027.
 */
define(function () {
    return {};
});