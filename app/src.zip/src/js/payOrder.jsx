/**
 * 支付iframe
 */
const React = require("react");
const IS_NODE_ENV_PRODUCTION = (process.env.NODE_ENV === 'production');
const HOST = IS_NODE_ENV_PRODUCTION?"you.163.com":"release.you.163.com";
const PIN_HOST = IS_NODE_ENV_PRODUCTION?"m.pin.mail.163.com":"m.pintest.mail.163.com";

const connectToStores = require("alt-utils/lib/connectToStores");
const MyOrderAction = require("pin-alt/src/actions/myOrderAction");
const OrderStore = require("pin-alt/src/stores/orderStore");

class PayOrder extends React.Component {
    constructor(props){
        super(props);
        this.orderId = this.props.location.query.orderId;
        MyOrderAction.getOrderInfo(this.orderId);
    }

    static getStores(){
        return [OrderStore];
    }

    static getPropsFromStores(){
        return OrderStore.getState();
    }

    render(){
        let {order} = this.props;
        if(order) {
            let orderId = order.yx_order_id;
            let url = "http://" + HOST + "/webmail/order/toPay?orderId=" + orderId + "&pin_host=" + PIN_HOST;
            return <div className="f-page pay">
                <iframe src={url} width="100%" scrolling="no" frameBorder="0"
                        style={{'height': '80vh'}}/>
            </div>
        }else{
            return null;
        }
    }
}

module.exports = connectToStores(PayOrder);