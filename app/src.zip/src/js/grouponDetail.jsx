"use strict"
const {Link} = require("react-router");
const React = require("react");
const moment = require("moment");
const Faq = require("../module/faq");
const Report = require("../module/report");
const Panels = require("../module/panels");
const Detail = require("../module/detail");
const Comments = require("../module/comments");
const Recommend = require("../module/recommend");
const Shortcuts = require("../module/shortcuts");
const ShareTips = require("../module/shareTips");
const ChooseJoin = require("../module/chooseJoin");

const Steps = require("../module/steps");
const util = require('pin-util/src/web_util');

const RemainTime = require("../module/remainTime");

const connectToStores = require("alt-utils/lib/connectToStores");
const GrouponAction = require("pin-alt/src/actions/grouponAction");
const GrouponStore = require("pin-alt/src/stores/grouponStore");
const GoodsAction = require("pin-alt/src/actions/goodsAction");
const OrderAction = require("pin-alt/src/actions/myOrderAction");
const OrderStore = require("pin-alt/src/stores/myOrderStore");
const GoodsStore = require("../store/goodsStore");
const MobileUtil = require("../mobileUtil");
const WeixinUtil = require("../weixinUtil");

class GrouponDetail extends React.Component{
    constructor(props) {
        super(props);

        this.state = {
            showShareTips: false,
            showGroupDetail: false
        };

        this.onScroll = this.onScroll.bind(this);
        this.onJoinClick = this.onJoinClick.bind(this);

        GrouponStore.listen(this.getListener());
        GrouponAction.getDetail(this.props.params.grouponId);
    }
    static getStores(){
        return [GrouponStore, OrderStore, GoodsStore];
    }

    static getPropsFromStores(){
		return {
			...GrouponStore.getState(),
			...OrderStore.getState(),
            ...GoodsStore.getState()
		}
    }

    componentWillUnmount(){
        window.removeEventListener('scroll', this.onScroll);
    }

    componentWillMount(){
        window.scrollTo(0,0);

        WeixinUtil.isWeixin() && WeixinUtil.init();
        window.addEventListener('scroll', this.onScroll);
    }

    onJoinClick(){
        let {grouponDetail, history, location} = this.props;
        if(grouponDetail.goods.isMega){
            history.pushState(null, '/groupon/create?goodsId=' + grouponDetail.goods._id + '&grouponId=' + grouponDetail._id);
        }else{
            history.pushState(null, location.pathname + '?sku=true');
        }
    }

    onScroll(){
        let body = document.body;
        let doc = document.documentElement;
        let max = doc.scrollHeight - doc.clientHeight;
        let top = body.scrollTop;

        if (!this.props.loading && (top >= max || max < 0)) {
            // 评论翻页
            if(this.refs && this.refs.comments){
                let gid = this.props.grouponDetail.goods._id;
                let {page, size, totalPage} = this.props.pagination;

                if (top >= max && page < Math.min(totalPage, 5)) {
                    GoodsAction.getComments(gid, {start: page * size}, '');
                }
            }
        }
    }

    getListener(){
        let loaded = false;
        return this.listener = (store)=>{
            try{
                let gid = store.grouponDetail.goods._id;

                if(this.isMember(store) && store.grouponDetail.status == 1){
                    this.setState({
                        showShareTips: true
                    });
                }

                if(!loaded) {
                    loaded = true;
                    GoodsAction.getComments(gid, {start: 0}, '');
                    GoodsAction.getRecommends(gid);
                    GoodsAction.getSkuChoose(gid);
                }
            }catch (e){
                console.log(e);
            }
        };
    }

	isMember(props){
        let uid = MobileUtil.getUserName();
        let orders = (props || this.props).grouponDetail.orders;

        let res = orders.find((item)=>{
            if(uid == item.user.uid){
                return true;
            }
        });

        return !!res;
    }

    isCaptain(props){
        try {
            let uid = MobileUtil.getUserName();
            let captain = (props || this.props).grouponDetail.captain;

            return captain.uid == uid;
        }catch(e){
            return false;
        }
    }

    componentDidMount(){
        this.checkCount = 0;
    }

    componentWillUnmount(){
        this.checkCount = 0;
    }

    render(){
        let {grouponDetail, comments, recommends, pagination, location, params, loading, history} = this.props;

        if(!grouponDetail){
            return null;
        }

        let goods = grouponDetail.goods,
            groupon = grouponDetail;
        var remain = groupon.groupQuota - groupon.orders.length;
        var items = [];
        for(var i=0;i<remain;i++){
            items.push(i);
        }

        let image = util.getImage(goods.image250,goods.imageToken,'intro');

        if(WeixinUtil.isWeixin()) {
            let shareConfig = {
                title: goods.name, // 分享标题
                desc: goods.shareTextMobile, // 分享描述
                link: window.location.href, // 分享链接
                imgUrl: image, // 分享图标
                dataUrl: ''
            };

            WeixinUtil.setShare(shareConfig);
        }

        let orderId = location.query.yx_order_id || location.query.orderId;
        let isResult = this.isMember() && orderId;
        let remainQuota = Math.max(grouponDetail.groupQuota - grouponDetail.orders.length, 0);

        // 单独够去结果页
        if(grouponDetail.groupQuota == 1){
            history.replaceState({}, '/payResult?orderId=' + (orderId||''));
            return null;
        }

        // 处理支付完但团未开始
        if(grouponDetail.status == 0 && orderId){
            if(!this.checkTimer && this.checkCount < 15){
                this.checkTimer = setTimeout(()=> {
                    this.checkTimer = null;
                    GrouponAction.getDetail(params.grouponId);
                    this.checkCount++;
                }, 3000);
            }
            return <div className="w-loading"></div>;
        }

        return <div className="f-page group">
            <div className="f-body fixedFooter">
				<div className="w-goods simple">
                    <div className="pic">
                        <img src={image} alt={goods.name}/>
                    </div>

                    <div className="info">
                        <h2>{goods.name}</h2>
                        <p>{goods.specification}</p>
                        {/*<p>数量：</p>*/}
                        <p>{groupon.groupQuota}人团：<strong className="w-price">￥{goods.mobilePrice}</strong><span className="t-str">（包邮）</span></p>
                    </div>
                </div>

                <div className="main">
                    <ul className="w-members">
                        {groupon.orders.map((order, n)=>{
                            return <li key={n}>
                                <img className="w-face" src={MobileUtil.getUserAvatar(order.user.uid)}/>
                                {
                                    (()=>{
                                        if(n == 0){
                                            return <div className="label leader">团长</div>;
                                        }else if(n == 1){
                                            return <div className="label">沙发</div>
                                        }
                                    })()
                                }
                                <span className="name">{order.user.name || order.user.uid}</span>
                            </li>;
                        })}
                        {items.map((item, n) => {
                            return <li key={n}>
                                <img className="w-face"
                                     src={util.getCacheUrl('/img/face.png')}/>
                            </li>;
                        })}
                    </ul>

                    {
                        (()=>{
                            if(grouponDetail.status == 2){
                                return <i className="mark i-group-suc" />;
                            }else if(grouponDetail.status == 3){
                                return <i className="mark i-group-fail" />;
                            }else if(grouponDetail.status == 4){
                                return <i className="mark i-group-fail" />;
                            }
                        })()
                    }

                    {
                        (()=>{
                            if(grouponDetail.status == 1 && remain > 0){
                                return <p className="tips">还差 <em className="t-str">{remainQuota}</em> 人，盼你如冬日盼暖阳！</p>
                            }else if(grouponDetail.status == 2){
                                return <p className="tips t-suc">组团成功，该团已结束！</p>
                            }else if(grouponDetail.status == 3){
                                return <p className="tips">组团失败，该团已结束！</p>
                            }else if(grouponDetail.status == 4){
                                return <p className="tips">组团失败，该团已结束！</p>
                            }
                        })()
                    }

                    {grouponDetail.status == 1 && <RemainTime time={moment(groupon.create_time).add(1,'d')} type={"detail"}/>}

                    <span className="showGroupDetail" onClick={()=>{
                        this.setState({
                            showGroupDetail: !this.state.showGroupDetail
                        });
                    }}>
                        查看全部团详情 <i className={'i-arr-' + (this.state.showGroupDetail ? 'up' : 'down')}></i>
                     </span>

                    {this.state.showGroupDetail &&
                    <ul className="w-memberList">
                        {groupon.orders.map((order, n)=> {
                            return <li key={n} className={'item-' + n}>
                                <img className="w-face" src={MobileUtil.getUserAvatar(order.user.uid)}/>
                                <span className="name">{order.user.name || order.user.uid}</span>
                                <span
                                    className="time">{moment(order.create_time).format('YYYY-MM-DD HH:mm:ss')} {n == 0 ? '开团' : '参团'}</span>
                            </li>;
                        })}
                    </ul>
                    }

                </div>

                <Panels>
                    <div tab="商品详情">
                        <Detail goods={goods}/>
                        <Report goods={goods}/>
                        <Faq />
                        <Recommend items={recommends}/>
                    </div>
                    <Comments tab="全部评论" ref="comments" badge={pagination && pagination.allTotal} comments={comments}/>
                </Panels>
            </div>
            <div className="f-footer shadowed fixed">
                {
                    (()=>{
                        if(grouponDetail.status == 1){
                            {/*if(this.isMember()){*/}
                                {/*return <div className="w-operation divided">*/}
                                    {/*<a href="javascript:void(0);" className="share" onClick={()=>this.setState({showShareTips:true})}><i className="i-weixin"></i>邀请好友参团</a>*/}
                                {/*</div>*/}
                            {/*} else {*/}
                                return <div className="w-operation divided">
                                    <Link to="/" className="back"><i className="i-home active"></i>更多拼团</Link>

                                    <a href="javascript:void(0)" className="main" onClick={this.onJoinClick}><strong>￥{goods.mobilePrice}</strong> 包邮 | 我也要参团</a>

                                    {/*<Link*/}
                                        {/*to={'/groupon/create?goodsId=' + goods._id + '&grouponId=' + grouponDetail._id + '&count=1'}*/}
                                        {/*className="main">*/}
                                        {/*<strong>￥{goods.mobilePrice}</strong> 包邮 | 我也要参团*/}
                                    {/*</Link>*/}
                                </div>
                            {/*}*/}
                        }else{
                            return <div className="w-operation divided">
                                <Link to="/" className="back"><i className="i-home active"></i>更多拼团</Link>
                                    {!goods.isMega &&
                                        <Link
                                            to={'/groupon/create?goodsId=' + goods._id + '&count=1'}
                                            className="main">{this.isCaptain() ? '再来开一个团' : '我也要开个团'}
                                        </Link>
                                    }
                            </div>
                        }
                    })()
                }

                <Shortcuts />
                <Link to="/help"><i className="i-help"></i></Link>
            </div>

            <ChooseJoin hidden={!location.query.sku} {...this.props}/>
            {this.state.showShareTips && <ShareTips remain={remainQuota} onClick={()=>this.setState({showShareTips:false})} />}
        </div>;
    }
}
module.exports = connectToStores(GrouponDetail);