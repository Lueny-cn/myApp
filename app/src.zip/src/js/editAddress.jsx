/**
 * 地址选择
 */
const React = require("react");
const {Link} = require("react-router");

const AddressItem = require('../subItem/addressItem');
const Msgbox = require('../module/msgbox');

const ShipAddressAction = require("pin-alt/src/actions/shipAddressAction");
const ShipAddressStore = require("pin-alt/src/stores/shipAddressStore");

const connectToStores = require("alt-utils/lib/connectToStores");


const PROVINCE = 0;
const CITY = 1;
const DISTRICT = 2;

class EditAddress extends React.Component {

    constructor(props){
        super(props);

        this.state = {
            tips: '',
            shipAddress: {
                dft: false,
                name: '',
                mobile: '',
                address: '',
                province: {id: '', name: ''},
                city: {id: '', name: ''},
                district: {id: '', name: ''}
            }
        };

        this.isAdd = !props.params.addressId;
    }

    static getStores(){
        return [ShipAddressStore];
    }

    static getPropsFromStores(){
        return ShipAddressStore.getState();
    }

    validate(){
        let shipAddress = this.state.shipAddress;
        let errMsg = '';

        if (!shipAddress.name || shipAddress.name.length == 0) {
            errMsg = "请填写收货人";
        }else if(/[<|>]/.test(shipAddress.name)){
            errMsg = "请不要输入<>字符";
        }else if (!shipAddress.mobile || shipAddress.mobile.length == 0) {
            errMsg = "请填写手机号码";
        } else if (!(/^1[3|4|5|7|8]\d{9}$/.test(shipAddress.mobile)) && !/^\d{3}\*{4}\d{4}$/.test(shipAddress.mobile)) {
            errMsg = "请正确填写11位手机号码";
        } else if (shipAddress.province.id=='省' || shipAddress.city.id=='市' || shipAddress.district.id=='区') {
            errMsg = "请选择所在地区";
        } else if (!shipAddress.address || shipAddress.address.length == 0) {
            errMsg = "请填写详细地址";
        }else if(/[<|>]/.test(shipAddress.address)){
            errMsg = "请不要输入<>字符";
        }else if(!shipAddress.province.id || !shipAddress.province.name){
            errMsg = "请选择省";
        }else if(!shipAddress.city.id || !shipAddress.city.name){
            errMsg = "请选择市";
        }else if(!shipAddress.district.id || !shipAddress.district.name){
            errMsg = "请选择区/县";
        }

        if(errMsg) {
            throw errMsg;
        }
    }

    onSubmit(){
        try{
            this.validate();
            if (this.isAdd) {
                ShipAddressAction.addShipAddress(this.state.shipAddress, ()=> {
                    this.props.history.goBack();
                });
            } else {
                ShipAddressAction.editShipAddress(this.state.shipAddress, ()=> {
                    this.props.history.goBack();
                });
            }
        }catch(e){
            this.alert(e);
        }
    }

    alert(text){
        this.setState({
            tips: text
        });
    }

    getCurrentAddress(){
        if(!this.current) {
            let {params, shipAddressList} = this.props;
            if (shipAddressList && shipAddressList.length > 0) {
                let current = this.current = shipAddressList.find((item)=> {
                    return item._id == params.addressId;
                });

                if(current) {
                    this.state.shipAddress = current;
                }
            }
        }
        return this.current;
    }

    getSelectClass(num){
        let active = false;
        let {shipAddress} = this.state;

        switch(num){
            case PROVINCE:
                active = !!shipAddress.province.id;
                break;
            case CITY:
                active = !!shipAddress.city.id;
                break;
            case DISTRICT:
                active = !!shipAddress.district.id;
                break;
            default:
                break;
        }

        return active ? ' area-value' : '';
    }

    onProvinceChange(id){
        id = id || this.provinceSelect.value;

        if(id) {
            ShipAddressAction.getCities(id);

            let {province, city, district} = this.state.shipAddress;
            let current = this.props.provinces.find((item)=> {
                return item.id == id;
            });

            province.id = id;
            province.name = current.zonename;

            city.id = '';
            city.name = '';

            district.id = '';
            district.name = '';

            this.setState(this.state);
        }
    }

    onCityChange(id){
        id = id || this.citySelect.value;

        if(id) {
            ShipAddressAction.getDistricts(id);

            let cityState = this.state.shipAddress.city;
            let current = this.props.cities.find((item)=> {
                return item.id == id;
            });

            cityState.id = id;
            cityState.name = current.zonename;
            this.setState(this.state);
        }
    }

    onDistrictChange(id){
        id = id || this.districtSelect.value;

        if(id) {
            let districtState = this.state.shipAddress.district;
            let current = this.props.districts.find((item)=> {
                return item.id == id;
            });

            districtState.id = id;
            districtState.name = current.zonename;
            this.setState(this.state);
        }
    }

    onInputChange(key, value){
        this.state.shipAddress[key] = value
        this.setState(this.state);
    }

    onDftChange(checked){
        this.state.shipAddress.dft = checked;
        this.setState(this.state);
    }

    componentDidMount(){
        let {addressId} = this.props.params;
        if(addressId) {
            ShipAddressAction.getShipAddressList();
        }
        ShipAddressAction.getProvinces();
    }

    getValue(key, subKey){
        let address = this.state.shipAddress;

        if(address) {
            let current = this.current || address;
            let value = address[key] === undefined ? current[key] : address[key];

            return subKey ? (value || {})[subKey] : value;
        }
    }

    render(){

        let {provinces, cities, districts, params} = this.props;

        if(!provinces) {
            return null;
        }

        if(this.getCurrentAddress() && !this.citiesAndDistrictsInited){
            let {province, city} = this.current;
            ShipAddressAction.getCitiesAndDistricts(province.id, city.id);
            this.citiesAndDistrictsInited = true;
        }

        return <div className="f-page addrEdit">
                    <div className="w-box">
                        <input ref={(el)=>this.nameInput=el}
                               type="text"
                               placeholder="姓名"
                               value={this.getValue('name')}
                               onChange={(e)=>{this.onInputChange('name', e.target.value)}}/>
                    </div>
                    <div className="w-box">
                        <input ref={(el)=>this.mobileInput=el}
                               type="text" placeholder="手机号码"
                               maxLength="11"
                               value={this.getValue('mobile')}
                               onChange={(e)=>{this.onInputChange('mobile', e.target.value)}}/>
                    </div>
                    <div className="w-box selectBox">
                        <select value={this.getValue('province', 'id')}
                                ref={(el)=>this.provinceSelect=el}
                                className={"area"+ this.getSelectClass(PROVINCE) }
                                onChange={(e) => { this.onProvinceChange() }} >
                            <option value="">省</option>
                            {provinces.map((item, n)=>{
                                return <option key={n} value={item.id}>{item.zonename}</option>
                            })}
                        </select>
                    </div>

                    <div className="w-box selectBox">
                        <select value={this.getValue('city', 'id')}
                                ref={(el)=>this.citySelect=el}
                                className={"area" + this.getSelectClass(CITY)}
                                onChange={(e) => { this.onCityChange() }}>

                            <option value="">市</option>
                            {cities.map((item, n)=>{
                                return <option key={n} value={item.id}>{item.zonename}</option>
                            })}
                        </select>
                    </div>

                    <div className="w-box selectBox">
                        <select value={this.getValue('district', 'id')}
                                ref={(el)=>this.districtSelect=el}
                                className={"area" + this.getSelectClass(DISTRICT)}
                                onChange={(e) => { this.onDistrictChange() }}>

                            <option value="">区/县 </option>
                            {districts.map((item, n)=>{
                                return <option key={n} value={item.id}>{item.zonename}</option>
                            })}
                        </select>
                    </div>
                    <div className="w-box">
                        <input ref={el=>this.addressInput=el}
                               type="text"
                               placeholder="详细地址，如街道、楼牌号等"
                               value={this.getValue('address')}
                               onChange={(e)=>{this.onInputChange('address', e.target.value)}}/>
                    </div>

                    <div className="default">
                        <input checked={this.getValue('dft')}
                               onChange={e=>this.onDftChange(e.target.checked)}
                               ref={el=>this.dftCheckBox=el}
                               type="checkbox"
                               id="tick" />

                        <label htmlFor="tick" className="red-t choose"></label>
                        <label htmlFor="tick" className="default-p">设为默认地址</label>
                    </div>

                    <div className="save" >
                        {/*{!this.isAdd &&*/}
                        {/*<input onClick={this.onRemove.bind(this)}*/}
                               {/*type="button"*/}
                               {/*value="删除地址"*/}
                               {/*className="delAddr"/>*/}
                        {/*}*/}

                        <input onClick={this.onSubmit.bind(this)}
                               type="submit"
                               value="保存地址"
                               className="saveAddr"/>
                    </div>

                    {this.state.tips && <Msgbox center={true} title={this.state.tips} onOkClick={()=>{
                        this.setState({tips: ''})
                    }}/>}
                </div>;

    }
}

module.exports = connectToStores(EditAddress);