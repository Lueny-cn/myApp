"use strict"
const React = require("react");
const Nav = require("../module/nav");
const connectToStores = require("alt-utils/lib/connectToStores");
const IndexAction = require("../action/indexAction");
const IndexStore = require("../store/indexStore");
const IndexItem = require("../subItem/indexItem");
const util = require('pin-util/src/web_util');
const SlideShow = require("../module/slideshow");
const Shortcuts = require("../module/shortcuts");


class Index extends React.Component{
    constructor(props) {
        super(props);
        this.state={
            firstCateId:this.props.currentCateId,
            showCateId:this.props.currentCateId
        };
        this.onScroll = this.onScroll.bind(this);
        this.cateScrollPosition = [];
        this.fetchedFirst = false;
        this.listener = (store) => {
            if(store.categories.length > 0){
                try {
                    if(!this.fetchedFirst){
                        this.fetchedFirst = true;
                        IndexAction.fetchGoodsByCategoryId(store.categories[0]._id, true);
                        IndexAction.fetchGoodsByCategoryId(store.categories[1]._id);
                        this.setState({firstCateId:store.categories[0]._id});
                    }else if(store.loading == false){
                        this.loading = false;
                    }
                }catch(e){}
            }else{
                return null;
            }
        }
        IndexStore.listen(this.listener);
    }
    static getStores() {
        return [IndexStore];
    }

    static getPropsFromStores() {
        return IndexStore.getState();
    }

    componentWillReceiveProps(nextProps){
        if(this.state.showCateId != nextProps.currentCateId){
            this.setState({showCateId : nextProps.currentCateId});
        }
    }

    componentWillMount() {
        window.addEventListener("scroll",this.onScroll,false);
    }

    componentWillUnmount(){
        IndexAction.setScrollPostion($(window).scrollTop());
        IndexStore.unlisten(this.listener);
        window.removeEventListener("scroll",this.onScroll,false);
    }

    showMore(){
        let {categories,currentCateId,cateGoodsMap} = this.props;
        let currentCateIndex = categories.findIndex((item)=>{
            return item._id == currentCateId;
        });
        if(currentCateIndex==-1){currentCateIndex=0;}
        if(currentCateIndex+1 >= categories.length){
            return;
        }
        let cateID = categories[currentCateIndex+1]._id;
        let nextCateID = categories[currentCateIndex+2] && categories[currentCateIndex+2]._id;

        if (cateGoodsMap[cateID]) {
            IndexAction.getGoodsByCategoryIdFromCache(cateID, false);
            nextCateID && IndexAction.fetchGoodsByCategoryId(nextCateID);
        }else{
            IndexAction.fetchGoodsByCategoryId(cateID, true);
            nextCateID && IndexAction.fetchGoodsByCategoryId(nextCateID);
        }
    }

    onScroll(){
        let {currentCateId} = this.props;
        let scrollTop = $(window).scrollTop();
        let findCateIndex = this.cateScrollPosition.findIndex((catePosition)=>{
           if(catePosition.position - scrollTop > 0){
                return true;
           }else{
               return false;
           }
        }) - 1;

        let oClientRect,nImgWindowTop,nImgWindowBottom,nWinHeight;
        if($(".w-bottom").length>0){
             oClientRect = $(".w-bottom")[0].getBoundingClientRect();
              nImgWindowTop = parseInt(oClientRect.top);
             nImgWindowBottom = parseInt(oClientRect.bottom);
             nWinHeight=$(window).height();
        }
        if(!this.loading && ((oClientRect&&nImgWindowTop * nImgWindowBottom < 0 || nImgWindowTop >= 0 && nImgWindowBottom > 0&& nImgWindowTop < nWinHeight))){
            this.loading = true;
            this.showMore();
        }else if(!this.loading && findCateIndex >= -1){
            //判断是否在类目下
            this.setState({showCateId:this.cateScrollPosition[findCateIndex==-1?0:findCateIndex].cateId});
        }else if(!this.loading && findCateIndex == -2){
            this.setState({showCateId:currentCateId});
        }
    }

    changeCategory(cateId){
        let{cateGoodsMap}= this.props;
        if(cateGoodsMap[cateId]){
            IndexAction.getGoodsByCategoryId(cateId,true);
            // IndexAction.getGoodsByCategoryIdFromCache(cateId,true);
        }else{
            IndexAction.fetchGoodsByCategoryId(cateId, true, true);
        }
        this.cateScrollPosition = [];
        this.setState({firstCateId:cateId});
        window.scrollTo(0,0);
    }

    componentDidUpdate(){
        // $(".w-tabs .active")[0]&&$(".w-tabs .active")[0].scrollIntoView();
        if(this.cateScrollPosition.findIndex((catePosition)=>{
            return catePosition.cateId == this.props.currentCateId;
            }) ==-1 && this.props.currentCateId){
            this.cateScrollPosition.push({
                cateId:this.props.currentCateId,
                position:$(window).scrollTop()
            });
        }
    }

    componentDidMount(){
        if(this.props.banners.length<=0){
            IndexAction.getBanners();
            IndexAction.getCategories();
        }else{
            //确认第一个是不是显示categories[0]._id
            let {cateGoods,cateGoodsMap,categories}= this.props;
            if(categories.length>0 && cateGoods.length>0 && cateGoodsMap[categories[0]._id]){
                if(cateGoodsMap[categories[0]._id].length>0 && cateGoods.indexOf(cateGoodsMap[categories[0]._id][0]) == 0){
                    this.setState({firstCateId:categories[0]._id});
                }
            }
            //回到原来定位的地方
            window.scrollTo(0,this.props.scrollPosition);
        }
    }


    render(){
        let {banners,categories,currentCateId,cateGoods}    = this.props;
        let {showCateId,firstCateId} = this.state;
        //处理banner
        if(banners){
            banners.sort((a, b)=>{
                return a.position - b.position;
            });

            banners.map((item, n) => {
                item.img = item.imageUrl;
                let goodsDteail;
                if(item.goods){
                    goodsDteail =  "/goodsDetail/" + item.goods._id;
                }
                item.href = item.url || goodsDteail;
            })
        }

        return <div className="f-page index" >
            <div className="f-header fixed shadowed">
                <div className="w-categories">

                    <nav className="w-tabs" >
                        {categories ? categories.map((item,n)=>{
                            return <a className={item._id == showCateId?"active":""}
                                      key={n}
                                      onClick={()=>{this.changeCategory(item._id)}}>{item.name}</a>;
                        }) : null}
                    </nav>
                </div>
            </div>

            <div className="f-body fixedHeader fixedFooter">

                {banners.length > 0 && categories.length>0 &&firstCateId == categories[0]._id?
                    <SlideShow items={banners}/>  : null
                }

                <div className="goodsList">

                    <IndexItem categorie = {cateGoods}
                               history={this.props.history} />
                    {
                        categories.findIndex((item)=>{
                            return item._id == currentCateId
                        }) < categories.length-1 ?
                            <div className="w-bottom" >
                                继续上滑将切换到下一个频道
                            </div>
                            :
                            <div className="w-bottomLine">已经到底部了</div>
                    }
                </div>
            </div>
            <div className="f-footer fixed">
                <Nav activeOn={0}/>
                <Shortcuts/>
            </div>
        </div>;
    }
}

module.exports = connectToStores(Index);