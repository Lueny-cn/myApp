/**
 * Created by Zyingying on 2016/10/11 0011.
 */
"use strict"
const React = require("react");
const {Link} = require("react-router");

const connectToStores = require("alt-utils/lib/connectToStores");
const MyOrderAction = require("pin-alt/src/actions/myOrderAction");
const MyOrderStore = require("pin-alt/src/stores/myOrderStore");
const util = require('pin-util/src/web_util');
const moment = require("moment");

class Delivery extends React.Component {

    constructor(props) {
        super(props);
    }

    static getStores() {
        return [MyOrderStore];
    }

    static getPropsFromStores() {
        return MyOrderStore.getState();
    }

    componentWillMount() {
        MyOrderAction.getDeliveryInfo(this.props.params.orderId);
    }

    componentDidMount() {
    }

    render() {

        let deliveryInfo = this.props.deliveryInfo;
        if (!deliveryInfo) {    return null; }
        let dContent = deliveryInfo.content || {};

        return <div className="f-page delivery">
            <div className="company gray">
                <div className="main f-left">
                    <p>物流公司：<span className="black">{deliveryInfo.company}</span></p>
                    <p>物流单号：<span className="black">{deliveryInfo.number}</span></p>
                </div>
                <div className="delivery-logo">
                    <i className="i-delivery-icon"></i>
                </div>
            </div>
            <div className="progress">
                <div className="vertical-line"></div>
                {dContent ? dContent.map((item, n )=>{
                    return  <div className={n == 0 ? "step active" :"step"} key={n}>
                                <i className="point"></i>
                                <div className="detail">
                                    <p className="msg">{item.desc}</p>
                                    <p className="gray">{moment(item.time).format('YYYY-MM-DD HH:mm:ss')}</p>
                                </div>
                            </div>;
                        }) : null}

            </div>

        </div>;
    }
}

module.exports = connectToStores(Delivery);
