"use strict"
const React = require("react");
const Bar =require("../module/bar");
const Nav = require("../module/nav");
const {Link} = require("react-router");
const connectToStores = require("alt-utils/lib/connectToStores");
const PersonalAction = require("pin-alt/src/actions/personalAction");
const PersonalStore = require("pin-alt/src/stores/personalStore");
const MobileUtil = require("../mobileUtil");
const WeixinUtil = require("../weixinUtil");

const classNames = require("classnames");

class Personal extends React.Component{
    constructor(props){
        super(props);
        let uid =  window._pin_data &&  window._pin_data._user && window._pin_data._user.uid;
        PersonalAction.getAvatar(uid,55);
        PersonalAction.getUserName();
        PersonalAction.getStartingGroupons();
        PersonalAction.getReadyReceiveOrders();
    }
    static getStores(){
        return [PersonalStore];
    }

    static getPropsFromStores(){
        return PersonalStore.getState();
    }

    logout(){
        location.href = 'http://reg.163.com/Logout.jsp?url=' + encodeURIComponent(location.href.replace(/\/?#.+$/, ''));
    }

    showListType(page,num){
        let history = this.props.history;
        history.pushState(null, page + "?showType=" + num);
    }

    render(){
        let {avatarUrl,userName,unpaidedOrderCount} = this.props,
            unpaid ,
            nopay = unpaidedOrderCount,
            startGroup = this.props.startingGrouponCount - 0,
            receive = this.props.readyReceiveOrdersCount - 0;

        if(unpaidedOrderCount > 0){
            unpaid = <span className="number">{unpaidedOrderCount}</span>;
        }
        let uid =  window._pin_data &&  window._pin_data._user && window._pin_data._user.uid;
        let configs = [{

            text: <Link className="item" to="/myGroupons">
                <i className="i-group icon"></i>我的团
            </Link>,
            next:true,
            bordered:true
        },
        {
            text: <Link className="item" to="/redPacket">
                <i className="i-redPacket icon"></i>我的红包
                </Link>,
            next:true,
            marginB:true
        },
        {
            text: <Link className="item" to="/personMsg"><i className="i-user icon"></i>个人资料</Link>,
            next:true,
            bordered:true
        }, {
            text: <Link className="item" to="/myAddresses"><i className="i-address icon"></i>地址管理</Link>,
            next:true,
            marginB:true
        },
        {
            text:<Link className="item" to="/help"><i className="i-warning icon"></i>拼团介绍</Link>,
            next:true,
            marginB:true
        },
        {
            text:<a href="tel:400-0368-163" className="item"><i className="i-tel icon"></i>客服电话<span className="tel">400-0368-163</span></a>,
            next:true
        }];

        return <div className="f-page personal">
                    <header>
                        <div className="w-user-img">
                            <img className="w-face big"
                                 src={avatarUrl}
                                 alt="头像"/>
                            <div className="user-msg">
                                <div className="w-username">{userName}</div>
                                <div className="wechatUser">
                                    {WeixinUtil.isWeixin()?
                                        '已绑定微信' :
                                    MobileUtil.getUserName()}
                                </div>
                            </div>
                        </div>
                    </header>

                    <div className="main">

                        <div className="orderMain marginB">
                            <div className="w-bar next bordered">
                                <Link className="item" to="/myOrders">我的订单
                                    {/*{unpaid}*/}
                                    <span className="allOrder">查看全部</span>
                                </Link>
                            </div>
                            <div className="orderQuick">
                                <div className="choose"
                                     onClick={()=>{this.showListType('/myOrders' ,1)}}>
                                    <i className="i-noPay icon"></i>
                                    <span className="intro">
                                        待付款
                                        {nopay > 0 ? <em className="w-badge">{nopay}</em>:null}
                                    </span>
                                </div>

                                <div className="choose"
                                     onClick={()=>{this.showListType('/myOrders' ,4)}}>
                                    <i className="i-group icon icoList"></i>
                                    <span className="intro">
                                        拼团中
                                        {startGroup > 0 ?
                                            <em className="w-badge">{startGroup}</em>
                                            :null
                                        }
                                    </span>
                                </div>

                                <div className="choose"
                                     onClick={()=>{this.showListType('/myOrders',2)}}>
                                    <i className="i-receive icon"></i>
                                    <span className="intro">
                                        待收货
                                        {receive > 0 ? <em className="w-badge">{receive}</em>:null}
                                    </span>
                                </div>
                            </div>
                        </div>

                        {
                            configs.map((config,nIndex)=>{
                                return <div className={
                                    classNames({
                                        'w-bar':true ,
                                        'next': config.next,
                                        'bordered':config.bordered,
                                        'marginB' :config.marginB
                                    })
                                }  key={nIndex}>{config.text}</div>;
                            })
                        }
                        <div className="w-signOut" onClick={this.logout}>退出登录</div>

                    </div>

                    <div className="f-footer fixed">
                        <Nav activeOn={3}/>
                    </div>
                 </div>;
            }
}
module.exports = connectToStores(Personal);