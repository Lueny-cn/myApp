/**
 * 右下角快捷操作
 */
const React = require("react");

class Shortcuts extends React.Component {
    constructor(props){
        super(props);

        this.state = {
            showGoTop: false
        };

        this.onScroll = this.onScroll.bind(this);
    }

    goTop(){
        window.scrollTo(0, 0);
    }

    onScroll(e){
        if(document.body.scrollTop >= document.documentElement.clientHeight/3){
            if(!this.state.showGoTop) {
                this.setState({
                    showGoTop: true
                });
            }
        }else if(this.state.showGoTop){
            this.setState({
                showGoTop: false
            });
        }
    }

    componentWillMount(){
        window.addEventListener('scroll', this.onScroll);
    }

    componentWillUnmount(){
        window.removeEventListener('scroll', this.onScroll);
    }

    render(){
        let {onShare} = this.props;
        let showGoTop = this.state.showGoTop;
        return <div className="w-shortcuts">
                    <a style={{
                        transform: 'translate3d(0,' + (showGoTop ? '0' : '100%') + ',0)',
                        transition: 'all .3s ease-in-out',
                        opacity: showGoTop ? '1' : '0'
                    }} href="javascript:void(0);" onClick={this.goTop}><i className="i-up"></i></a>
                    {onShare && <a href="javascript:void(0);" onClick={onShare}>分享</a>}
                </div>
    }
}

module.exports = Shortcuts;