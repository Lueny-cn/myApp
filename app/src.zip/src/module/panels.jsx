/**
 * 通用选项卡内容联动组件
 */
const React = require("react");
const Tabs = require("./tabs");

class Panels extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            active: props.active || 0,
            fixed: false
        }

        this.onTabChange = this.onTabChange.bind(this);
        this.onScroll = this.onScroll.bind(this);
    }

    onTabChange(n){
        this.setState({active: n});
    }

    onScroll(){
        let body = document.body;
        let wrapper = this.refs.wrapper;
        let y = wrapper.offsetTop - body.scrollTop;

        if(y <= 0){
            if(!this.state.fixed) {
                this.setState({fixed: true})
            }
        }else{
            if(this.state.fixed) {
                this.setState({fixed: false})
            }
        }
    }

    componentWillUnmount(){
        if(this.props.autoFixed){
            window.removeEventListener('scroll', this.onScroll);
        }
    }

    componentWillMount(){
        if(this.props.autoFixed){
            window.addEventListener('scroll', this.onScroll);
        }
    }

    render(){
        let {children} = this.props;
        let {active, fixed} = this.state;

        children = children.length ? children : [children];

        let tabs = children.map((item, n)=>{
            return {
                text: item.props.tab,
                badge: item.props.badge
            }
        });

        return <div ref="wrapper" className={"w-panels" + (fixed ? ' fixedTab' : '')}>
                    <Tabs items={tabs} onChange={this.onTabChange} active={this.state.active}/>
                    {children.map((item, n)=>{
                        return active == n ? item : null;
                    })}
                </div>
    }
}

module.exports = Panels;