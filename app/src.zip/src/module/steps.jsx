
const React = require("react");
module.exports = function (props) {
	var {active} = props;
	return <ul className="w-steps">
		<li className={active == 0 ? 'active' : ''}>
			<strong>第1步</strong>
			<span>支付订单</span>
		</li>
		<li className={active == 1 ? 'active' : ''}>
			<strong>第2步</strong>
			<span>邀请好友</span>
		</li>
		<li className={active == 2 ? 'active' : ''}>
			<strong>第3步</strong>
			<span>组团成功</span>
		</li>
	</ul>
}
