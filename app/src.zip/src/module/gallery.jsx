/**
 * 图片查看
 */
const React = require("react");
const SlideShow = require("../module/slideshow");
const util = require('pin-util/src/web_util');

class Gallery extends React.Component {
    render(){
        return <div className="w-gallery" onClick={this.props.onClick}>
            <SlideShow {...this.props} autoSwitch={false} />
        </div>
    }
}

module.exports = Gallery;