/**
 * 质检报告
 */
const React = require("react");
const ReactDom = require("react-dom");
const util = require('pin-util/src/web_util');
const Gallery = require("../module/gallery");

class Report extends React.Component {
    constructor(props){
        super(props);

        this.state = {
            zoomIn: false
        };
    }

    render(){
        let {goods} = this.props;
        let images = goods.qualityImages;

        if(images && images.length > 0) {
            let imgs = images.map((item, n) => {
                item.img = util.getImage(item.url, goods.imageToken, 'quality');
                return item;
            })

            return <div>
                <div className="w-report">
                    <h2>质检报告</h2>
                    <div className="cover" onClick={()=>this.setState({zoomIn: true})}>
                        <img src={util.getImage(images[0].url, goods.imageToken, 'quality')} alt="质检报告"/>
                        <a href="javascript:void(0);" className="zoom"><i className="i-zoom"></i></a>
                    </div>
                </div>
                {this.state.zoomIn &&
                <Gallery items={imgs} onClick={()=>this.setState({zoomIn:false})}/>
                }
            </div>
        }else{
            return null;
        }
    }
}

module.exports = Report;