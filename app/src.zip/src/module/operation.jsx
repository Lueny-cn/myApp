/**
 * 底部操作栏
 */
const React = require("react");
const {Link} = require("react-router");

class Operation extends React.Component {
    render(){
        let {goodsId, goods, count, buyAble, soldOut, needSku} = this.props;
        let path = needSku ? '/goodsDetail/' + goodsId + '?sku=' + goodsId : '/groupon/create?goodsId=' + goodsId + '&count=' + (count || 1);
        let serviceUrl = window.ysf && ysf.url();

        return <div className="w-operation">
                    <Link to="/" className="back"><i className="i-home"></i>首页</Link>
                    {serviceUrl && <a className="service" href={serviceUrl}><i className="i-tel"></i>客服</a>}
                    {
                        (()=>{
                            if(goods.remain <= 0){
                                return <a href="javascript:void(0);" className="main disabled">已售罄</a>
                            }else if(!buyAble){
                                return <a href="javascript:void(0);" className="main disabled">已下架</a>
                            }else{

                                let btns = [];

                                if(!goods.forbidBuyAlone){
                                    btns.push(<Link href="javascript:void(0);" to={path + '&buyAlone=true'}>
                                        <span className="tips">￥{goods.yanPrice} + {goods.yanShipPrice}运费</span>
                                        <span className="text">单独购</span>
                                    </Link>);
                                }

                                if(!goods.forbidCreate){
                                    btns.push(<Link to={path} className="main" style={{flex: '1.5'}}>
                                        <span className="tips"><strong>￥{goods.mobilePrice}</strong> 包邮</span>
                                        <span className="text">{goods.groupQuota}人团 | 去开团</span>
                                    </Link>);
                                }

                                return btns;
                            }
                        })()
                    }
                </div>
    }
}

module.exports = Operation;