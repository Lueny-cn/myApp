"use strict"
const React = require("react");
const Operation = require("../module/operation");
const NumberInput = require("../module/numberInput");
const Sku = require("../module/sku");
const {Link} = require("react-router");

const connectToStores = require("alt-utils/lib/connectToStores");
const GoodsAction = require("pin-alt/src/actions/goodsAction");
const GoodsStore = require("pin-alt/src/stores/goodsStore");
const util = require('pin-util/src/web_util');
const MobileUtil = require('../mobileUtil');

class GoodsDetail extends React.Component{
    constructor(props) {
        super(props);

        this.state = {
            sku: null,
            count: 1,
            min: 1,
            max: 5,
            tips: '',
            couponTips: ''
        };

        this.onNumberInputChange = this.onNumberInputChange.bind(this);
        this.onNumberInputMax = this.onNumberInputMax.bind(this);
        this.onNumberInputMin = this.onNumberInputMin.bind(this);
        this.onSkuChange = this.onSkuChange.bind(this);
    }

    static getStores(){
        return [GoodsStore];
    }

    static getPropsFromStores(){
        return GoodsStore.getState();
    }


    onSkuChange(goodsId){
        let {buyAlone} = this.props.location.query;
        this.props.history.replaceState(null, '/goodsDetail/' + goodsId + '?sku=' + goodsId + (buyAlone ? '&buyAlone=true' : ''));
        this.setState({
            tips: '',
            couponTips: ''
        })
        GoodsAction.getDetail(goodsId);
    }

    onNumberInputMax(){
        let max = this.state.max;
        let remain = this.props.goodsDetail.goods.remain;

        this.setState({
            tips: remain < max ? '库存不足' : '每次限购' + max + '件'
        });
    }

    onNumberInputMin(){
        let min = this.state.min;
        let remain = this.props.goodsDetail.goods.remain;

        this.setState({
            tips: remain < min ? '库存不足' : '不能小于' + min + '件'
        });
    }

    onNumberInputChange(value){
        let query = this.props.location.query;
        let goods = this.props.goodsDetail.goods;
        let price = MobileUtil.getPriceDiscount(goods.mobilePrice, value);
        let nextPrice = MobileUtil.getPriceDiscount(goods.mobilePrice, value + 1);
        let nextSaveMoney = goods.mobilePrice * (value + 1) - nextPrice;
        let saveMoney = goods.mobilePrice * (value) - price;

        setTimeout(()=> {
            this.setState({
                count: value,
                tips: !query.buyAlone && (value > 1 ? (saveMoney > 0 ? '已帮您节省' + saveMoney + '元' : '') : (nextSaveMoney > 0 ? '多买1个省' + nextSaveMoney + '元' : ''))
            });
        }, 0);
    }

    render(){
        let {hidden, goodsDetail, params, location, history}= this.props;

        let {count, min, max} = this.state;
        let goodsId = params.goodsId;
        let goods = goodsDetail.goods;
        let buyAlone = !!location.query.buyAlone;

        if(!goods){
            GoodsAction.getDetail(goodsId);
            return null;
        }

        return <div>
                    <div onClick={()=>{history.goBack()}} className="w-mask" style={{display: hidden ? 'none' : 'block'}}></div>
                    <div className="f-layer choose" style={{
                        transform: 'translate3d(0, ' + (hidden ? '110%' : '0') + ', 0)'
                    }}>
                        <i className="i-close" onClick={()=>{history.goBack()}}></i>

                        <div className="w-goods normal">
                        <div className="pic">
                            <img src={util.getImage(goods.image250, goods.imageToken, 'intro')} alt=""/>
                        </div>

                        <div className="info">
                            <h2>{goods.name}</h2>
                            {buyAlone ?
                                <p><strong className="w-price">￥{goods.yanPrice}</strong> + {goods.yanShipPrice}元运费</p>
                                :
                                <p><strong className="w-price">￥{goods.mobilePrice}</strong></p>
                            }
                            <p>请选择规格数量</p>
                        </div>
                    </div>

                    <div className="sku w-block small">
                        <h2>规格</h2>
                        <Sku currentGoods={goodsId} onChange={this.onSkuChange}/>
                    </div>

                    {<div className="number w-block small">
                        <h2>购买数量</h2>
                        <span>
                            {!hidden && <NumberInput value={count} min={Math.min(min, goods.remain)} max={Math.min(max, goods.remain)} onMax={this.onNumberInputMax} onMin={this.onNumberInputMin} onChange={this.onNumberInputChange} />}
                            {/*{this.state.couponTips ? <span className="couponTips">{this.state.couponTips}</span> : null}*/}
                        </span>
                        <p className="tips t-str">
                            {this.state.tips}
                            {MobileUtil.isFewStock(goods.remain) && "（库存紧张）"}
                        </p>
                    </div>}

                    <div className="submit">
                        <Link disabled={count <= 0} className="w-btn main" to={'/groupon/create?goodsId=' + goodsId + '&count=' + (count || 1) + (buyAlone ? '&buyAlone=true' : '')}>确定</Link>
                    </div>

                    {/*<Operation count={this.state.count} goodsId={goodsId} goods={goods} buyAble={true} soldOut={MobileUtil.isFewStock(goods.remain+1)}/>*/}
                </div>
            </div>
    }
}

module.exports = connectToStores(GoodsDetail);