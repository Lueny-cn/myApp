/**
 * 商品详情
 */
const React = require("react");
const util = require('pin-util/src/web_util');

class Detail extends React.Component {

    getFeatures(){
        let {features} = this.props.goods;

        return features ? features.map((item, n)=>{
            return <tr key={n}>
                        <th>{item.name}</th>
                        <td>{item.value}</td>
                    </tr>
        }) : null;
    }

    getDetailImages(){
        let {detailImages, imageToken} = this.props.goods;

        return detailImages ? detailImages.map((item, n)=>{
            let src = util.getImage(item.url, imageToken, 'detail');
            return <img key={n} src={src} alt=""/>
        }) : null;
    }

    render(){
        let {goods} = this.props;

        if(!goods){return null}

        return  <div className="w-detail">
                    <div className="w-properties">
                        <table>
                            <tbody>
                                {this.getFeatures()}
                            </tbody>
                        </table>
                    </div>
                    {this.getDetailImages()}
                </div>
    }
}

module.exports = Detail;