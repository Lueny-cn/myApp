/**
 * 条
 */
const React = require("react");
const {Link} = require("react-router");
const classNames = require("classnames");

class Bar extends React.Component {
    render(){
        let {text, next, to, icon, bordered, value, valueType, onClick} = this.props;
        let cls = classNames({
            'w-bar': true,
            'hasIcon': !!icon,
            'next': next,
            'bordered': bordered
        });

        if(to){
            return <Link to={to}>
                        <div className={cls}>
                            {icon && <i className={icon}></i>}
                            {text}
                            {value && <span className={"value" + (valueType ? ' ' + valueType : '')}>{value}</span>}
                        </div>
                    </Link>
        }else{
            return <div className={cls} onClick={onClick}>
                        {icon && <i className={icon}></i>}
                        {text}
                        {value && <span className={"value" + (valueType ? ' ' + valueType : '')}>{value}</span>}
                    </div>
        }
    }
}

module.exports = Bar;