/**
 * 猜你喜欢
 */
const React = require("react");
const {Link} = require('react-router');
const util = require('pin-util/src/web_util');

class Recommend extends React.Component {
    render() {
        let items = this.props.items;
        if (items && items.length > 0){
            return <div className="w-recmd">
                <h2>你可能会喜欢</h2>
                <ul>
                    {
                        items.map((item, n)=> {
                            if(item.status == 1) {
                                let src = util.getImage(item.image250, item.imageToken, 'intro');
                                return <li key={n}>
                                    <Link to={"/goodsDetail/" + item._id}>
                                        <div className="pic">
                                            {item.productArea && <span className="w-label">{item.productArea}</span>}
                                            <img src={src}/>
                                        </div>
                                        <div className="text">
                                            <p className="name">{item.name}</p>
                                            <p className="desc">{item.desc}</p>
                                            <p className="price">￥{item.mobilePrice} <em>包邮</em> <span className="t-aside">￥{item.yanPrice + item.yanShipPrice}</span></p>
                                        </div>
                                    </Link>
                                </li>
                            }else{
                                return null;
                            }
                        })
                    }
                </ul>

                <div className="w-bottomLine">已经到底部了</div>
            </div>
        }else{
            return null;
        }
    }
}

module.exports = Recommend;