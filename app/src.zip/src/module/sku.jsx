"use strict"
const React = require("react");
const connectToStores = require("alt-utils/lib/connectToStores");
const GoodsAction = require("pin-alt/src/actions/goodsAction");
const GoodsStore = require("pin-alt/src/stores/goodsStore");
const {Link} = require("react-router");
const classNames = require("classnames");

class SkuChooseManage extends React.Component{
    componentWillMount(){
        if(typeof document != 'undefined'){
            let {currentGoods} = this.props;
            GoodsAction.getSkuChoose(currentGoods);
        }
    }

    static getStores(){
        return [GoodsStore];
    }

    static getPropsFromStores(){
        return GoodsStore.getState();
    }

    render(){
        let {currentGoods, currentSku, skuInfos, onChange} = this.props;
        let skuChoose = [];
        if(skuInfos){
            skuChoose = skuInfos.map((skuInfo,n)=>{
                let {skuDesc,skuImage,goodsId,buyAble} = skuInfo;

                return <span className={classNames({
                    'w-sku': true,
                    'active': currentGoods == goodsId,
                    'disabled' : !buyAble
                })} key={n} onClick={()=>{buyAble && onChange && onChange(goodsId)}}>{skuDesc}</span>
            })
        }

        return <div className="skuList">{skuChoose}</div>;

        //return <ul className="w-types">{skuChoose.length>0?skuChoose:<li className={skuCls}>{currentSku.skuImage?<img src={currentSku.skuImage.indexOf("?")>-1?currentSku.skuImage+"&thumbnail=30x30":currentSku.skuImage+"?imageView&thumbnail=30x30&quality=95"} alt={currentSku.skuDesc}/>:""}{currentSku.skuDesc}</li>}</ul>;
    }
}

module.exports = connectToStores(SkuChooseManage);
