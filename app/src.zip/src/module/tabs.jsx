/**
 * 选项卡
 */
const React = require("react");

class Tabs extends React.Component {
    constructor(props){
        super(props);

        this.state = {
            active: props.active || 0
        };

        this.onChange = this.props.onChange;
    }

    switchTo(n){
        this.setState({active: n});
        this.onChange && this.onChange(n);
    }

    getItems(){
        let {items,onGoing,notice,active} = this.props;
        // let active = this.state.active;
        let note;
        if(notice){
            note = <i className="i-dot"></i>;
        }else{
            note = onGoing > 0 && <em className="t-str">（{onGoing}）</em>
        }
        return items.map((item, n)=>{
            return <a key={n}
                      onClick={()=>this.switchTo(n)}
                      href="javascript:void(0);" className={active == n ? 'active' : ''}>
                        {item.text}
                        {item.tip > 0 ? note : null}
                        {item.badge > 0 && <em className="t-str">（{item.badge}）</em>}
                    </a>
        });
    }
    render(){
        return <nav className="w-tabs flex">{this.getItems()}</nav>
    }
}

module.exports = Tabs;