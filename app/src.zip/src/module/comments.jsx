/**
 * 评论列表
 */
const React = require("react");
const Comment = require("../subItem/commentItem");

class Detail extends React.Component {
    render(){
        let {comments} = this.props;
        if(!comments){return null;}

        return  <div className="w-commentsList">

                    {
                        comments.length > 0 ?
                            comments.map((item, n)=>{
                                return <Comment key={n} comment={item}/>
                            }) :
                            <div className="w-no-comment">
                                <i className="i-no-comment"></i>
                                <p className="no-p">该商品还没有评论哦</p>
                            </div>

                    }
                </div>
    }
}

module.exports = Detail;