/**
 * 分享遮罩提示
 */
const React = require("react");
const image = require("../img/share_tips.png");
const image_android = require("../img/share_tips_android.png");
const image_safari = require("../img/share_tips_safari.png");
const WeixinUnit = require("../weixinUtil");
const MobileUnit = require("../mobileUtil");

class ShareTips extends React.Component {
    render(){
        let {onClick, remain} = this.props;
        return <div className="w-shareTips" onClick={onClick}>
                    {remain > 0 &&
                        <span className="remain">还差 <em>{remain}</em> 人，邀请好友参团吧！<br/>组团成功，立即发货！</span>
                    }
                    <img src={
                        (()=>{
                            if(WeixinUnit.isWeixin()){
                                return image;
                            }else if(MobileUnit.isIOS()){
                                return image_safari;
                            }else{
                                return image_android;
                            }
                        })()
                    } alt="分享" style={!WeixinUnit.isWeixin() ? {
                        top: 'auto',
                        bottom: '.2rem'
                    } : null} />
                </div>
    }
}

module.exports = ShareTips;