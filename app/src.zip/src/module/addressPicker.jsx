/**
 * 地址选择
 */
const React = require("react");
const {Link} = require("react-router");

const AddressItem = require("../subItem/addressItem");
const Bar = require("../module/bar");
const WeixinUtil = require("../weixinUtil");
const MobileUtil = require("../mobileUtil");

const ShipAddressAction = require("pin-alt/src/actions/shipAddressAction");
const ShipAddressStore = require("pin-alt/src/stores/shipAddressStore");

const connectToStores = require("alt-utils/lib/connectToStores");

class Address extends React.Component {

    constructor(props) {
        super(props);
        ShipAddressAction.getShipAddressList();
    }

    static getStores() {
        return [ShipAddressStore];
    }

    static getPropsFromStores() {
        return ShipAddressStore.getState();
    }

    getWxAddress(){
        WeixinUtil.init(()=>{
            WeixinUtil.address(MobileUtil.getUserName(), (suc, res)=>{
                if(suc) {
                    ShipAddressAction.syncShipAddress(res, ()=> {
                        ShipAddressAction.getShipAddressList();
                    });
                }
            });
        });
    }

    render() {
        let {goodsId, grouponId, count, buyAlone, shipAddressList, onClick, addressId, onDefault} = this.props;

        if(!shipAddressList){
            return null;
        }

        if (shipAddressList.length == 0) {
            if(WeixinUtil.isWeixin()){
                return <div>
                    <Bar icon="i-add-round" bordered={true} text="手动添加收货地址" to="/address/add" next={true}/>
                    <Bar onClick={this.getWxAddress.bind(this)} icon="i-wx" text="一键获取微信地址" next={true}/>
                </div>;
            } else {
                return <div>
                    <div className="w-noAddr">
                        <p>你还没有收货地址，请添加一个收货地址。</p>
                        <Link to="/address/add" className="w-btn newOne">新建地址</Link>
                    </div>
                </div>;
            }
        } else {
            let current = addressId && shipAddressList.find((item)=> {
                    return addressId == item._id;
                });

            let dft = shipAddressList.find((item)=> {
                return item.dft;
            });

            let address = current || dft || shipAddressList[0];

            if(!current) {
                onDefault && onDefault(address._id);
            }

            return <Link to={"/address/choose?choose=true&goodsId=" + goodsId + "&count=" + count + (grouponId ? '&grouponId=' + grouponId:'') + (buyAlone ? '&buyAlone=true':'')}>
                <i className="icon i-addr-active"></i>
                <AddressItem onClick={onClick} address={address} editable={false}
                             selectable={true}/>
            </Link>
        }

    }
}

module.exports = connectToStores(Address);