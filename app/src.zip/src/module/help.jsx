/**
 * 拼团玩法
 */
const React = require("react");
const {Link} = require("react-router");
const helpImg = require("../img/help.png");

class Help extends React.Component {
    render(){
        return <div className="w-help">
                    <h2>拼团玩法<Link to="/help" className="more">查看详情</Link></h2>
                    <img src={helpImg} alt="拼团玩法" />
                </div>
    }
}

module.exports = Help;