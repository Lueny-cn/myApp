"use strict"
const React = require("react");
const connectToStores = require("alt-utils/lib/connectToStores");
const GoodsAction = require("pin-alt/src/actions/goodsAction");
const GoodsStore = require("pin-alt/src/stores/goodsStore");
const classNames = require("classnames");
const Sku = require("../module/sku");
const {Link} = require("react-router");
const MobileUtil = require('../mobileUtil');

class ChooseJoin extends React.Component{
    constructor(props) {
        super(props);

        this.state = {
           choose: null
        };

        this.onSubmit = this.onSubmit.bind(this);
        this.onSkuChange = this.onSkuChange.bind(this);

    }

    static getStores(){
        return [GoodsStore];
    }

    static getPropsFromStores(){
        return GoodsStore.getState();
    }

    onSkuChange(goodsId){
        this.setState({choose: goodsId});
    }

    onSubmit(){
        let {grouponDetail, history} = this.props;
        history.pushState(null, '/groupon/create?' + 'goodsId=' + (this.state.choose || grouponDetail.goods._id) + '&grouponId=' + grouponDetail._id);
    }

    render(){
        let {hidden, grouponDetail, history, skuInfos} = this.props;
        let choose = this.state.choose || grouponDetail.goods._id;
        let {captain, goods} = grouponDetail;

        // // 只有一个sku直接提交？
        // if(skuInfos && skuInfos.length == 1){
        //     this.onSubmit();
        //     return null;
        // }

        return <div>
                    <div onClick={()=>{history.goBack()}} className="w-mask" style={{display: hidden ? 'none' : 'block'}}></div>
                    <div className="f-layer join" style={{
                        transform: 'translate3d(0, ' + (hidden ? '110%' : '0') + ', 0)'
                    }}>
                        <i className="i-close" onClick={()=>{history.goBack()}}></i>
                        <div className="info">
                            <h2>
                                <img className="w-face" src={MobileUtil.getUserAvatar(captain.uid)}/>
                                参加 <em>{captain.name}</em> 开的团
                            </h2>
                            <p><span onClick={()=>{this.onSkuChange(goods._id)}} className={'w-sku' + (choose == goods._id ? ' active' : '')}>{goods.skuDesc || goods.specification}</span></p>
                        </div>

                        {skuInfos.length > 1 &&
                            <div className="sku">
                                <h2 className="t-sec">选择其他规格</h2>
                                {skuInfos.filter((item, n)=> {
                                    return item.goodsId != goods._id;
                                }).map((item, n)=> {
                                    let {skuDesc, buyAble} = item;

                                    return <span className={classNames({
                                        'w-sku': true,
                                        'active': choose == item.goodsId,
                                        'disabled': !buyAble
                                    })} key={n} onClick={buyAble ? ()=> {
                                        this.onSkuChange(item.goodsId)
                                    } : null}>{skuDesc}</span>
                                })}
                            </div>
                        }

                        <div className="submit">
                            <a href="javascript:void(0);" onClick={e=>this.onSubmit(choose)} className="w-btn main">确定</a>
                        </div>
                    </div>
                </div>
    }
}

module.exports = connectToStores(ChooseJoin);