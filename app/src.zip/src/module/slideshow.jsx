/**
 * 图片轮换
 */
const React = require("react");
const {Link} = require("react-router");
const MakeSlidable = require("./makeSlidable");
const util = require('pin-util/src/web_util');

class SlideShow extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            active: props.active || 0
        };

        this.autoSwitch = props.autoSwitch !== false;
        this.interval = props.interval || 5000;
    }

    componentDidMount(){
        this.startInterval();
    }


    componentWillUnmount(){
        this.stopInterval();
    }

    startInterval(){
        if(this.autoSwitch) {
            this.timer = setInterval(()=> {
                let n = this.state.active + 1;
                this.switchTo(n % this.props.items.length);
            }, this.interval);
        }
    }

    stopInterval(){
        clearInterval(this.timer);
    }

    switchTo(n){
        if(n >= 0 && n < this.props.items.length) {
            this.setState({active: n});
        }
    }

    onSlideStart(){
        this.stopInterval();
        this.left = this.refs.pics.offsetLeft;
        this.refs.pics.style.transitionDuration = '0s';
    }

    onSlideEnd(x){
        let pics = this.refs.pics;
        pics.style.left = this.left + 'px';
        pics.style.transitionDuration = '';

        if(Math.abs(x) > document.documentElement.clientWidth / 4){
            let next = this.state.active + (x < 0 ? 1 : -1);
            this.switchTo(next);
        }
        this.startInterval();
    }

    onSlideLeft(x){
        let dis = this.state.active == this.props.items.length - 1 ? x/6 : x;
        this.refs.pics.style.left = this.left + dis + 'px';
    }

    onSlideRight(x){
        let dis = this.state.active == 0 ? x/6 : x;
        this.refs.pics.style.left = this.left + dis + 'px';
    }

    render(){
        let {items, onClick} = this.props;
        let {active} = this.state;
        let  alink ;


        return <div className="w-slideShow" onClick={onClick}>
                    <div ref="pics" className="pics" style={{'left': (-active * 100) + '%'}}>
                        {
                            items.map((item, n) => {
                                let img = <img src={item.img || item}/>;
                                if(item.href){
                                    alink = <Link to={item.href} key={n} href="javascript:void(0);">{img}</Link>

                                    if(/^https?:\/\//.test(item.href)) {
                                        alink = <a key={n} href={item.href}>{img}</a>
                                    }
                                }else{
                                    alink = <a key={n} href="javascript:void(0)">{img}</a>
                                }

                                return alink;
                            })
                        }
                    </div>

                    <span className="dots">
                        {
                            items.map((item, n) => {
                                return <span key={n} className={active == n ? 'active' : ''}></span>;
                            })
                        }
                    </span>
                </div>
    }
}

module.exports = MakeSlidable(SlideShow);