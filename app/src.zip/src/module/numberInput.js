/**
 * 数字输入框
 */
const React = require("react");

class NumberInput extends React.Component {
    constructor(props){
        super(props);

        this.onMinusClick = this.onMinusClick.bind(this);
        this.onPlusClick = this.onPlusClick.bind(this);
        this.onInputChange = this.onInputChange.bind(this);
        this.onInputFocus = this.onInputFocus.bind(this);

        this.setValue(props.value);
    }

    setValue(value){
        let {max, min, onChange, onMin, onMax} = this.props;

        let isMin = false;
        let isMax = false;

        if (value < min) {
            value = min;
            isMin = true;
        } else if (value > max) {
            value = max;
            isMax = true;
        }

        if(isMax){
            onMax && onMax();
        }else if(isMin){
            onMin && onMin();
        }

        if(this.value != value) {
            onChange && onChange(value);
        }

        this.value = value;
        this.refs.input && (this.refs.input.value = value);
    }

    onInputFocus(e){
        e.target.select();
    }

    onInputChange(e){
        let value = e.target.value - 0;
        if(!isNaN(value)) {
            this.setValue(value);
        }else{
            this.setValue(this.value);
        }
    }

    onMinusClick(){
        this.setValue(this.value - 1);
    }

    onPlusClick(){
        this.setValue(this.value + 1);
    }

    render(){
        let disabled = this.props.disabled;
        return <div className="w-numberInput">
                    <a href="javascript:void(0);" onClick={disabled ? null : this.onMinusClick}>-</a>
                    <input disabled={disabled} type="text" pattern="[0-9]*" ref="input" defaultValue={this.value} onFocus={this.onInputFocus} onChange={this.onInputChange}/>
                    <a href="javascript:void(0);" onClick={disabled ? null : this.onPlusClick}>+</a>
                </div>
    }
}

module.exports = NumberInput;