/**
 *  剩余时间倒计时
 */

"use strict";
const React = require("react");
const moment = require('moment');
class RemainTime extends React.Component{
  constructor(props) {
    super(props);
    this.state={remainTime:null};
  }

  fillZero (value) {
    return value > 9 ? value : ('0' + value);
  }
  getRemainTime_default(startTime){
    let time = moment.duration(moment(startTime).toDate().getTime()-new Date().getTime());
    let remainTime = ["<label>活动时间：</label>","剩余"];
    if(time.days()){
      remainTime[remainTime.length] = "<em>"+time.days()+"</em>天";
    }

    if(time.hours() || !time.days()){
      remainTime[remainTime.length] = "<em>"+this.fillZero(time.hours())+"</em>小时";
    }

    if(time.minutes() || time.days() || time.hours()){
      remainTime[remainTime.length] = "<em>"+this.fillZero(time.minutes())+"</em>分钟";
    }

    if(time.seconds()|| time.days() || time.hours() || time.minutes()){
      let milliseconds = Math.floor(time.milliseconds()/100);
      remainTime[remainTime.length] = "<em class='t-impt'>"+this.fillZero(time.seconds())+"."+milliseconds+"</em>秒";
    }

    return remainTime.join("");
  }

  getRemainTime_detail(startTime){
    let time = moment.duration(moment(startTime).toDate().getTime()-new Date().getTime());
    let remainTime = ["剩余"];
    if(time.hours() || !time.days()){
      remainTime[remainTime.length] = "<em class='num'>"+this.fillZero(time.hours())+"</em><span class='split'>:</span>";
    }

    if(time.minutes() || time.days() || time.hours()){
      remainTime[remainTime.length] = "<em class='num'>"+this.fillZero(time.minutes())+"</em><span class='split'>:</span>";
    }

    if(time.seconds()|| time.days() || time.hours() || time.minutes()){
      let milliseconds = Math.floor(time.milliseconds()/100);
      remainTime[remainTime.length] = "<em class='num'>"+this.fillZero(time.seconds())+"</em>";
    }
    remainTime.push("结束");
    return remainTime.join("");
  }

  componentWillUnmount(){
      clearInterval(this.timer);
  }

  componentDidMount(){
    let {time,type} = this.props,getRemainTimeFn;
    switch(type){
      case 'detail':
        getRemainTimeFn = this.getRemainTime_detail.bind(this);
        break;
      default: getRemainTimeFn = this.getRemainTime_default.bind(this);break;
    }

    this.timer = setInterval(function(){
      this.setState({remainTime:getRemainTimeFn(time)});
    }.bind(this),100);
  }

  render(){
    let {time,type} = this.props;
    let {remainTime} = this.state,getRemainTimeFn;
    if(!remainTime){
      switch(type){
        case 'detail':
          getRemainTimeFn = this.getRemainTime_detail.bind(this);
           break;
        default: getRemainTimeFn = this.getRemainTime_default.bind(this);break;
      }
      remainTime = getRemainTimeFn(time)
    }
    if(!type){
      return <li className="countdown" dangerouslySetInnerHTML={{__html:remainTime}}></li>;
    }else if (type == 'detail'){
      return <div className="w-countdown" dangerouslySetInnerHTML={{__html:remainTime}}></div>;
    }
  }
}
module.exports = RemainTime;
