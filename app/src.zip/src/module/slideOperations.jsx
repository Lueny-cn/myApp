/**
 * 滑动操作
 */
const React = require("react");
const MakeSlidable = require("./makeSlidable");

class SlideOperations extends React.Component {
    constructor(props){
        super(props);
        this.active = false;

        this.onBodyClick = this.onBodyClick.bind(this);
    }

    componentWillUnmount(){
        document.documentElement.removeEventListener('touchstart', this.onBodyClick);
    }

    componentDidMount(){
        this.slide = this.refs.slidable;
        this.slideStyle = this.refs.slidable.style;
        this.opts = this.refs.operations;

        document.documentElement.addEventListener('touchstart', this.onBodyClick);
    }

    onBodyClick(){
        this.reset();
    }

    onSlideStart(){
        this.left = this.refs.slidable.offsetLeft;
        this.slideStyle.transition = '';
    }

    onSlideEnd(x){
        this.slideStyle.transition = 'left .1s ease-in-out';
        if(Math.abs(x) >= this.opts.offsetWidth){
            this.setActive();
        }else{
            this.reset();
        }
    }

    setActive(){
        this.slideStyle.left = - this.opts.offsetWidth + 'px';
        this.active = true;
    }

    reset(){
        this.active = false;
        this.slideStyle.left = '0';
    }

    onSlideLeft(x){
        this.slideStyle.left = this.left + x + 'px';
    }

    onSlideRight(x){
        this.slideStyle.left = Math.round((this.left + x)/4) + 'px';
    }

    onTouchStart(e){
        this.startX = e.touches[0].clientX;
    }

    onTouchEnd(e){
        let onClick = this.props.onClick;
        let endX = e.changedTouches[0].clientX;
        if(onClick) {
            if ((Math.abs(endX - this.startX) <= 6)) {
                onClick();
            }
        }
    }

    render(){
        let {operations, onOperate, onClick} = this.props;

        return <div className="w-slideOperations" onTouchStart={this.onTouchStart.bind(this)} onTouchEnd={this.onTouchEnd.bind(this)}>
                    <div ref="slidable" className="slidable">{this.props.children}</div>
                    <div ref="operations" className="operations">{
                        (()=>{
                            let items = [];
                            for(let key in operations){
                                items.push(<a onTouchStart={(e)=>{
                                    onOperate && onOperate(key);
                                    e.stopPropagation();
                                }} className={operations.color || 'red'} key={items.length} href="javascript:void(0);"><span>{operations[key]}</span></a>);
                            }
                            return items;
                        })()
                    }</div>
                </div>
    }
}

module.exports = MakeSlidable(SlideOperations);