/**
 * 弹框
 */

const React = require("react");
const {Link} = require("react-router");
const connectToStores = require("alt-utils/lib/connectToStores");
const MyOrderAction = require("pin-alt/src/actions/myOrderAction");
const MyOrderStore = require("pin-alt/src/stores/myOrderStore");

class Confirm extends React.Component {
    constructor(props){
        super(props);
    }

    cancelOrder(order){
        this.props.changeConfirmVisible();
        MyOrderAction.cancelOrder(order._id);
        location.reload();
    }

    render(){
        let order = this.props.order;
        if(!order){
            return null;
        }
        return <div className="w-confirm">
                <div className="confirmBox">
                    <p className="content">是否取消此订单？</p>
                    <div className="choose">
                        <a className="false"
                           href="javascript:void(0);"
                           onClick={this.props.changeConfirmVisible}>否</a>

                        <a className="true"
                           href="javascript:void(0);"
                           onClick={this.cancelOrder.bind(this,order)}>是</a>
                    </div>
                </div>
            </div>

    }
}


module.exports = Confirm;