/**
 * Created by Zyingying on 2016/10/27 0027.
 */
const React = require("react");
const JoinItem = require("../subItem/joinItem");

class OtherGroup extends React.Component{
    constructor(props) {
        super(props);
    }

    render(){

        return <div className="w-OtherGroup">
             <p className="intro">不想自己开团?可参加以下网友开的团，组团成功立即发货</p>
            <div className="joinList">
                {
                    this.props.items.map((item, n)=>{
                        if(n < 4) {
                            return <JoinItem group={item} goods={this.props.goods} key={n}/>
                        }
                    })
                }
            </div>
        </div>;
    }

}

module.exports = OtherGroup;