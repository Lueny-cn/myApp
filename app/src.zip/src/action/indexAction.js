"use strict";

const Flux = require("pin-alt/src/flux");
class IndexAction {
	constructor() {
		this.url = {
			"getCategories": "/api/mobile/category",
			"getGoods": "/api/mobile/goods",
			"getBanners": "/api/mobile/banner",
			"getGoodsByCategoryId": "/api/mobile/getGoodsByCategoryId"
		};
		this.generateActions('getGoodsByCategoryIdSuccess', 'getGoodsByCategoryIdFail',
            'fetchGoodsByCategoryIdSuccess', 'fetchGoodsByCategoryIdFail',
			'getCategoriesSuccess', 'getCategoriesFail', 'getGoodsSuccess', 'getGoodsFail', 
			'getBannersSuccess', 'getBannersFail','getGoodsByCategoryIdFromCacheSuccess','setScrollPositionSuccess' );
	}

	getCategories() {
		$.getJSON(this.url["getCategories"], data => {
			this.getCategoriesSuccess(data.result);
		});
	}

	fetchGoodsByCategoryId(categoryId, get, refresh){
        $.getJSON(this.url["getGoodsByCategoryId"] + '?categoryId=' + categoryId, data => {
            this.fetchGoodsByCategoryIdSuccess(data.result, get, refresh);
        });
    }

	getGoodsByCategoryId(categoryId,refresh) {
		// $.getJSON(this.url["getGoodsByCategoryId"] + '?categoryId=' + categoryId, data => {
			this.getGoodsByCategoryIdSuccess(categoryId,refresh);
		// });
	}
	getGoodsByCategoryIdFromCache(categoryId,refresh){
		this.getGoodsByCategoryIdFromCacheSuccess(categoryId,refresh);
	}

	getGoods() {
		$.getJSON(this.url["getGoods"], data => {
			this.getGoodsSuccess(data.result);
		});
	}

	getBanners() {
		$.getJSON(this.url["getBanners"], data => {
			this.getBannersSuccess(data.result);
		});
	}
	setScrollPostion(position){
		this.setScrollPositionSuccess(position);
	}

}
module.exports = Flux.createActions(IndexAction);
