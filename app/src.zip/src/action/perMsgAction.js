"use strict";
const Flux = require("pin-alt/src/flux");
class PersonalMsgAction {

    constructor(){
        this.url = {
            getUser:"/api/user/getUser",
            modifyUser:"api/user/modifyUser"
        };
        this.generateActions('getUserSuccess','getUserFail','postMsgSuccess','postMsgFail');
        this._cacheAvatar = {};
    }


    getUser(){
        let sUrl = this.url["getUser"];
        $.ajax({
            url: sUrl,
            type: 'get',
            dataType:"json",
            success: (result)=> {
                if(result.code == 200) {
                    this.getUserSuccess(result.result);
                }else{
                    this.getUserFail();
                }
            },
            error: ()=> {
                this.getUserFail();
            }
        });
    }

    modifyUser(data,fn){
        let sUrl = this.url["modifyUser"];
        $.ajax({
            url: sUrl,
            type: 'post',
            dataType:"json",
            data:data,
            success: (result)=> {
                if(result.code == 200) {
                    this.postMsgSuccess();
                    fn();
                }else{
                    this.postMsgFail();
                }
            },
            error: ()=> {
                this.postMsgFail();
            }
        });
    }


}
module.exports = Flux.createActions(PersonalMsgAction);
