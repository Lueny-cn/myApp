"use strict"
//const Router = require("react-router/Router");
//const Route = require("react-router/Route");
require("./css/style.scss");
const React = require("react");
const {IndexRoute,Route,Router} = require("react-router");
const ReactDom = require("react-dom");
const createHashHistory = require( 'history/lib/createHashHistory');

const App = require("./app.jsx");
const Index = require("./js/index.jsx");
const GoodsDetail = require("./js/goodsDetail.jsx");
const GrouponDetail = require("./js/grouponDetail.jsx");
const MyOrders = require("./js/myOrders.jsx");
const MyGroupons = require("./js/myGroupons.jsx");
const Help = require("./js/help.jsx");
const personMsg = require("./js/personalMsg");
const SubmitOrder = require("./js/submitOrder.jsx");
const Personal = require("./js/peronsal.jsx");
const EditAddress = require("./js/editAddress.jsx");
const MyAddresses = require("./js/myAddresses.jsx");
const OrderDetail = require("./js/orderDetail.jsx");
const PayOrder = require("./js/payOrder.jsx");
const Delivery = require("./js/delivery.jsx");
const Login = require("./js/login.jsx");
const Redirect = require("./js/redirect.jsx");
const PayResult = require("./js/payResult.jsx");
const Faq = require("./js/faq.jsx");
const redPacket = require('./js/myRedPackets');


const mobileUtil = require("./mobileUtil");

function requireLogin(nextState, replace){
    if(!mobileUtil.isLogin()){
        if(window.__needReloadForLogin){
            // replace(null, nextState.location.pathname);
            window.location.reload();
        } else {
            replace({nextState: nextState}, '/login');
        }
    }
}

let routes = <Router history={createHashHistory()}>
                <Route path="/" component={App}>
                    <IndexRoute component={Index} />
                    <Route path="login" components={Login}/>
                    <Route path="myOrders" components={MyOrders} onEnter={requireLogin}/>
                    <Route path="myGroupons" components={MyGroupons} onEnter={requireLogin}/>
                    <Route path="myAddresses" components={MyAddresses} onEnter={requireLogin}/>
                    <Route path="category/:catId" components={Index}/>
                    <Route path="help" components={Help}/>
                    <Route path="goodsDetail/:goodsId" components={GoodsDetail}/>
                    <Route path="groupon/create" components={SubmitOrder} onEnter={requireLogin}/>
                    <Route path="payResult" components={PayResult}/>
                    <Route path="grouponDetail/:grouponId" components={GrouponDetail}/>
                    <Route path="groupon/gopay" components={PayOrder} onEnter={requireLogin}/>
                    <Route path="personal" components={Personal} onEnter={requireLogin}/>
                    <Route path="address/choose" components={MyAddresses} onEnter={requireLogin}/>
                    <Route path="address/edit/:addressId" components={EditAddress} onEnter={requireLogin}/>
                    <Route path="orderDetail/:orderId" components={OrderDetail} onEnter={requireLogin}/>
                    <Route path="delivery/:orderId" components={Delivery} onEnter={requireLogin}/>
                    <Route path="address/add" components={EditAddress} onEnter={requireLogin}/>
                    <Route path="redirect" components={Redirect}/>
                    <Route path="faq" component={Faq} />
                    <Route path="personMsg" component={personMsg} onEnter={requireLogin}/>
                    <Route path="redPacket" component={redPacket}/>
                </Route>
            </Router>;
ReactDom.render(routes,document.getElementById("App"));
